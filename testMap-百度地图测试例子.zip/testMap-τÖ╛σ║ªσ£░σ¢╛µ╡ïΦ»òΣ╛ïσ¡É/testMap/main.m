//
//  main.m
//  testMap
//
//  Created by kitegkp on 16/3/19.
//  Copyright © 2016年 kitegkp. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
