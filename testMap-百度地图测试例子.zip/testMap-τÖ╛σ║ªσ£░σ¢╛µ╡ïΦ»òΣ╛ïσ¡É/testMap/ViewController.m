//
//  ViewController.m
//  testMap
//
//  Created by kitegkp on 16/3/19.
//  Copyright © 2016年 kitegkp. All rights reserved.
//

#import "ViewController.h"
#import <BaiduMapAPI_Location/BMKLocationService.h>
#import <BaiduMapAPI_Base/BMKUserLocation.h>
#import <BaiduMapAPI_Map/BMKMapView.h>
#import <BaiduMapAPI_Map/BMKPointAnnotation.h>
#import <BaiduMapAPI_Search/BMKGeoCodeSearch.h>


@interface ViewController ()<BMKMapViewDelegate,BMKLocationServiceDelegate,BMKGeoCodeSearchDelegate>
{
    BMKLocationService* _locService;
    BMKMapView* _mapView;
    BMKGeoCodeSearch * _searcher;
    UITextView * _tipView;
}
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    if(!_mapView){
        _mapView=[[BMKMapView alloc] initWithFrame:CGRectMake(30, 30,300,300)];
        [self.view addSubview:_mapView];

//        _mapView.showsUserLocation = YES;                //设置为可以显示用户位置
        [_mapView setZoomEnabled:YES];
        [_mapView setZoomLevel:20];

        //设置定位的状态
        _mapView.userTrackingMode = BMKUserTrackingModeFollow;
        //显示定位图层
        _mapView.showsUserLocation = YES;
        //设置定位图层自定义样式
        BMKLocationViewDisplayParam *userlocationStyle = [[BMKLocationViewDisplayParam alloc] init];
        //精度圈是否显示
        userlocationStyle.isRotateAngleValid = YES;
        //跟随态旋转角度是否生效
        userlocationStyle.isAccuracyCircleShow = NO;
//        _mapView.gesturesEnabled=NO;    //不允许手势操作了。

        //更新参样式信息
        [_mapView updateLocationViewWithParam:userlocationStyle];
        
    }

    
    //检索
    //初始化检索对象
    if(!_searcher){
        _searcher =[[BMKGeoCodeSearch alloc]init];
    }
    
    if (!_locService) {
        //初始化BMKLocationService
        _locService = [[BMKLocationService alloc]init];

        //设置距离过滤器(默认距离是米)
        _locService.distanceFilter =10;
        //设置定位精度
        _locService.desiredAccuracy = kCLLocationAccuracyBest;
        
//      _locService.headingFilter=180;
    }
    
    if (!_tipView) {
        _tipView=[[UITextView alloc] initWithFrame:CGRectMake(30, 350, 300, 200)];
        [self.view addSubview:_tipView];
        _tipView.editable=NO;
    }

    
}

-(void)viewWillAppear:(BOOL)animated {
    [_mapView viewWillAppear];
    _mapView.delegate = self; // 此处记得不用的时候需要置nil，否则影响内存的释放
     _searcher.delegate = self;
     _locService.delegate = self;

    //启动LocationService
    [_locService startUserLocationService];
    
}

-(void)viewWillDisappear:(BOOL)animated {
    [_mapView viewWillDisappear];
    _mapView.delegate = nil; // 不用时，置nil
    _searcher.delegate = nil;
    _locService.delegate = nil;
}
- (void)viewDidUnload {
    [super viewDidUnload];
}
- (void)dealloc {
    if (_mapView) {
        _mapView = nil;
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


#pragma mark - BMKMapViewDelegate

- (void)mapViewDidFinishLoading:(BMKMapView *)mapView {
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"" message:@"BMKMapView控件初始化完成" delegate:nil cancelButtonTitle:@"知道了" otherButtonTitles: nil];
    [alert show];
}

- (void)mapView:(BMKMapView *)mapView onClickedMapBlank:(CLLocationCoordinate2D)coordinate {
    NSLog(@"map view: click blank");
}

- (void)mapview:(BMKMapView *)mapView onDoubleClick:(CLLocationCoordinate2D)coordinate {
    NSLog(@"map view: double click");
}


#pragma mark - BMKLocationServiceDelegate
- (void)didUpdateUserHeading:(BMKUserLocation *)userLocation
{
//    NSLog(@"heading is %@",userLocation.heading);
}

//处理位置坐标更新
- (void)didUpdateBMKUserLocation:(BMKUserLocation *)userLocation
{
    // 23.139429,long 113.337771
    NSLog(@"didUpdateUserLocation lat %f,long %f",userLocation.location.coordinate.latitude,userLocation.location.coordinate.longitude);
    _tipView.text=[NSString stringWithFormat:@"%@\nlat %f,long %f",_tipView.text,userLocation.location.coordinate.latitude,userLocation.location.coordinate.longitude];
//    
//     [_mapView removeAnnotations:_mapView.annotations];
//
//    // 添加一个PointAnnotation
//    BMKPointAnnotation* annotation = [[BMKPointAnnotation alloc]init];
//    CLLocationCoordinate2D coor;
//    coor.latitude =userLocation.location.coordinate.latitude;
//    coor.longitude =userLocation.location.coordinate.longitude;
//    annotation.coordinate = coor;
//    annotation.title = userLocation.title;
//    [_mapView addAnnotation:annotation];
//     [_mapView setCenterCoordinate:annotation.coordinate animated:YES];
    
    //反地理编码出地理位置
    CLLocationCoordinate2D pt=(CLLocationCoordinate2D){0,0};
    pt=(CLLocationCoordinate2D){userLocation.location.coordinate.latitude,userLocation.location.coordinate.longitude};
    
    BMKReverseGeoCodeOption * temp =[[BMKReverseGeoCodeOption alloc] init];
    temp.reverseGeoPoint=pt;
    
    BOOL flag=[_searcher reverseGeoCode:temp];
    if (flag) {
        _mapView.showsUserLocation=NO;//不显示自己的位置
    }
    else{
        NSLog(@"无法搜索");
    }
//    [_locService stopUserLocationService];
}

- (void)didFailToLocateUserWithError:(NSError *)error{
    NSLog(@"获取失败");
}


- (void)onGetReverseGeoCodeResult:(BMKGeoCodeSearch *)searcher result:(BMKReverseGeoCodeResult *)result errorCode:(BMKSearchErrorCode)error{
//     [_mapView removeAnnotations:_mapView.annotations];
    
    if (error==0) {
        BMKPointAnnotation *item=[[BMKPointAnnotation alloc] init];
        item.coordinate=result.location;//地理坐标
        item.title=result.address;//地理名称
        [_mapView addAnnotation:item];
        _mapView.centerCoordinate=result.location;
        
        NSLog(@"地址： %@",result.address);
        NSLog(@"地址： %@",result.businessCircle);
        
    _tipView.text=[NSString stringWithFormat:@"%@\n地址 %@",_tipView.text,result.address];
//        NSLog(@"地址： %@",result.poiList);

    }


}








@end
