//
//  ZoomImgView.m
//  WebImageShow
//
//  Created by kitegkp on 15/7/11.
//  Copyright (c) 2015年 BW. All rights reserved.
//

#import "ZoomImgView.h"
#import "UIImageView+WebCache.h"

@interface ZoomImgView()<UIScrollViewDelegate>
{
    UIImageView *  _imgView;
}
@end

@implementation ZoomImgView
@synthesize zoomImgDelegate=_zoomImgDelegate;

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/
- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
        self.delegate = self;
    }
    return self;
}

- (id)init
{
    self = [super init];
    if (self) {
        // Initialization code
        self.delegate = self;
    }
    return self;
}

-(void)setImgViewWithUrl:(NSString*)urlStr
{
    if (!_imgView) {
        _imgView= [[UIImageView alloc] init];
         _imgView.userInteractionEnabled = YES;
        [self addSubview:_imgView];
        
        
        UITapGestureRecognizer *singleTapOne = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(exitViewSingleTap:)];
        singleTapOne.numberOfTouchesRequired = 1;
        singleTapOne.numberOfTapsRequired = 1;
        [self addGestureRecognizer:singleTapOne];
        
    }
    
    
    __block typeof(_imgView) imgViewTemp=_imgView;
    __block typeof(self) selfTemp=self;
    
    [_imgView setImageWithURL:[NSURL URLWithString:urlStr] placeholderImage:nil completed:^(UIImage *image,NSError *error,SDImageCacheType cacheType)
     {
         float height=0;
         height =selfTemp.frame.size.width/(image.size.width/image.size.height);
         imgViewTemp.frame=CGRectMake(0, 0,selfTemp.frame.size.width,height);
         imgViewTemp.center = selfTemp.center;
         [selfTemp setMinimumZoomScale:1];
         [selfTemp setMaximumZoomScale:4];
         [selfTemp setZoomScale:1];

     }];
}

#pragma mark - UIScrollViewDelegate

//方法倍数
- (void)scrollViewDidEndZooming:(UIScrollView *)scrollView withView:(UIView *)view atScale:(CGFloat)scale
{
    NSLog(@"scale %f",scale);
    [scrollView setZoomScale:scale animated:NO];
}
//让图片居中
- (void)scrollViewDidZoom:(UIScrollView *)scrollView
{
    if (!_imgView) {
        return;
    }
    
    CGFloat offsetX = (scrollView.bounds.size.width > scrollView.contentSize.width)?
    (scrollView.bounds.size.width - scrollView.contentSize.width) * 0.5 : 0.0;
    CGFloat offsetY = (scrollView.bounds.size.height > scrollView.contentSize.height)?
    (scrollView.bounds.size.height - scrollView.contentSize.height) * 0.5 : 0.0;
    _imgView.center = CGPointMake(scrollView.contentSize.width * 0.5 + offsetX,
                                 scrollView.contentSize.height * 0.5 + offsetY);
}

//缩放响应view
- (UIView *)viewForZoomingInScrollView:(UIScrollView *)scrollView
{
    if (!_imgView) {
        return nil;
    }
    
    return _imgView;
}


#pragma mark - 退出浏览图片View exitViewSingleTap
- (void)exitViewSingleTap:(UITapGestureRecognizer *)recognizer
{
    if (_zoomImgDelegate) { //点击图片浏览器事件
        [_zoomImgDelegate exitZoomImgView:self];
    }
    
}



@end
