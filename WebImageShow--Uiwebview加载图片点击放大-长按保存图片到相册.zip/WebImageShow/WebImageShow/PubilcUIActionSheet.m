//
//  PubilcUIActionSheet.m
//  WebImageShow
//
//  Created by kitegkp on 15/7/13.
//  Copyright (c) 2015年 BW. All rights reserved.
//

#import "PubilcUIActionSheet.h" 

@interface PubilcUIActionSheet()<UIActionSheetDelegate>
{
    PubilcUIActionSheet_Block _actionSheet_Block;

}
@end

@implementation PubilcUIActionSheet

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/
- (instancetype)initWithTitle:(NSString *)title  cancelButtonTitle:(NSString *)cancelButtonTitle destructiveButtonTitle:(NSString *)destructiveButtonTitle otherButtonTitles:(NSString *)otherButtonTitles otherButtonCallBack:(PubilcUIActionSheet_Block)callBack {

     PubilcUIActionSheet*   tempSelf= [super initWithTitle:title delegate:self cancelButtonTitle:cancelButtonTitle destructiveButtonTitle:destructiveButtonTitle otherButtonTitles:otherButtonTitles, nil];
   
    if (callBack) {
        _actionSheet_Block=callBack;
    }
    tempSelf.cancelButtonIndex = tempSelf.numberOfButtons - 1;
    return tempSelf;
}


// 功能：保存图片到手机
- (void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex {

    NSLog(@"点击 %ld",(long)buttonIndex);
    if (actionSheet.numberOfButtons - 1 == buttonIndex) {
        return;
    }
    if(_actionSheet_Block){
        _actionSheet_Block(nil);
    }
    
}



@end
