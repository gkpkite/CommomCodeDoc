//
//  PubilcUIActionSheet.h
//  WebImageShow
//
//  Created by kitegkp on 15/7/13.
//  Copyright (c) 2015年 BW. All rights reserved.
//

#import <UIKit/UIKit.h>


typedef void(^PubilcUIActionSheet_Block)(NSDictionary *info);
@interface PubilcUIActionSheet : UIActionSheet

- (instancetype)initWithTitle:(NSString *)title  cancelButtonTitle:(NSString *)cancelButtonTitle destructiveButtonTitle:(NSString *)destructiveButtonTitle otherButtonTitles:(NSString *)otherButtonTitles otherButtonCallBack:(PubilcUIActionSheet_Block)callBack;


@end
