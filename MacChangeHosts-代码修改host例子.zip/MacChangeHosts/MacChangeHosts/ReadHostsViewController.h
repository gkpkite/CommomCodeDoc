//
//  ReadHostsViewController.h
//  MacChangeHosts
//
//  Created by kitegkp on 15/10/8.
//  Copyright (c) 2015年 sanqi. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface ReadHostsViewController : NSViewController

@end
