//
//  main.m
//  MacChangeHosts
//
//  Created by kitegkp on 15/10/7.
//  Copyright (c) 2015年 sanqi. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, const char * argv[]) {
    return NSApplicationMain(argc, argv);
}
