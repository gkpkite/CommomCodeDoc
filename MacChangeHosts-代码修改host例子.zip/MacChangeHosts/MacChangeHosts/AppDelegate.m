//
//  AppDelegate.m
//  MacChangeHosts
//
//  Created by kitegkp on 15/10/7.
//  Copyright (c) 2015年 sanqi. All rights reserved.
//

#import "AppDelegate.h"
#import "ReadHostsViewController.h"

#define addressIPStr (@"14.18.237.185")
#define addressDnsStr (@"ht.37wan.com")
#define addressTipStr (@"#HT后台")

@interface AppDelegate ()
{
    ReadHostsViewController *  _readHostsViewController;
}
@property (weak) IBOutlet NSWindow *window;
@end

@implementation AppDelegate

- (void)applicationDidFinishLaunching:(NSNotification *)aNotification {

    [self.window setContentSize:NSMakeSize(400,250)];
 
//    if (!_hostsChange) {
//        _hostsChange=[[HostsChange alloc] init];
//    }
//    _hostsChange.view.frame = ((NSView*)self.window.contentView).bounds;
//  [self.window.contentView addSubview:_hostsChange.view];
    
    if (!_readHostsViewController) {
        _readHostsViewController=[[ReadHostsViewController alloc] initWithNibName:@"ReadHostsViewController" bundle:nil];
    }
    _readHostsViewController.view.frame = CGRectMake(0, 0, 400, 250);
    [self.window.contentView addSubview:_readHostsViewController.view];
    
    
//    [self writeHosts];
}

- (void)applicationWillTerminate:(NSNotification *)aNotification {
    // Insert code here to tear down your application
}


-(NSString*)readHosts
{
        NSString* readStr=@"";
        NSError *error;
        NSString *allTheLines = [NSString stringWithContentsOfFile:@"/private/etc/hosts"
                                                          encoding:NSUTF8StringEncoding
                                                             error:&error];
        if (error != nil) {
            NSLog(@"Some freaking error: %@", error);
        }
        
        NSArray *lines = [allTheLines componentsSeparatedByCharactersInSet:
                          [NSCharacterSet newlineCharacterSet]];
    
//        NSLog(@"lines %lu %@",(unsigned long)lines.count,lines);
    BOOL isExist=NO;
    
    for (NSString *line in lines) {
        NSLog(@"line %@ ",line);
        
        NSString* tempTestStr=[line stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
          NSLog(@"tempTestStr %@ ",tempTestStr);
        
        NSRange range0 = [tempTestStr rangeOfString:@"#"];   //已经注释掉
        NSRange range1 = [tempTestStr rangeOfString:addressIPStr];
        NSRange range2 = [tempTestStr rangeOfString:addressDnsStr];
        
        NSLog(@"tempTestStr %@  %lu %lu %lu %lu",tempTestStr,(unsigned long)range0.length,(unsigned long)range0.location,(unsigned long)range1.length,(unsigned long)range2.length);
        
        
        if((!(range0.length>0 && (range0.location==0))) &&  (range1.length>0) && (range2.length>0)){
            isExist=YES;
            break;
        }

       readStr=[NSString stringWithFormat:@"%@%@\n",readStr,line];
    }
    //NSString *message = [hosts componentsJoinedByString:@"\n"];
  
    if (isExist) {
        return nil;
    }
    return readStr;
}


-(void)writeHosts{
    
    if (![self readHosts]) {
        NSLog(@"已经存在！");
        
        return;
    }
    
    NSString* readStr=[self readHosts];
    readStr=[NSString stringWithFormat:@"%@\n%@  %@  %@",readStr,addressIPStr,addressDnsStr,addressTipStr];
    
    NSString *convertedPath = [NSString stringWithUTF8String:[@"/etc/hosts" UTF8String]];
    NSTask *task = [[NSTask alloc] init];
    NSPipe *pipe = [[NSPipe alloc] init];
    
    [task setLaunchPath:@"/usr/libexec/authopen"];
    [task setArguments:[NSArray arrayWithObjects:@"-c", @"-w", convertedPath, nil]];
    [task setStandardInput:pipe];
    [task launch];
    NSData* stringData  = [readStr dataUsingEncoding:NSUTF8StringEncoding];
    NSFileHandle *writeHandle = [pipe fileHandleForWriting];

    
    [writeHandle writeData:stringData];
    close([writeHandle fileDescriptor]); // Close it manually
    [writeHandle setValue:[NSNumber numberWithUnsignedShort:1] forKey:@"_flags"];
    [task waitUntilExit];
}


@end
