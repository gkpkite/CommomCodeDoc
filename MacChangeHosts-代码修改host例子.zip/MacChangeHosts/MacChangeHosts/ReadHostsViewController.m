//
//  ReadHostsViewController.m
//  MacChangeHosts
//
//  Created by kitegkp on 15/10/8.
//  Copyright (c) 2015年 sanqi. All rights reserved.
//

#import "ReadHostsViewController.h"
#import "KSPasswordField.h"

#define addressIPStr (@"14.18.237.185")
#define addressDnsStr (@"ht.37wan.com")
#define addressTipStr (@"#HT后台")

#define addressIPKey (@"addressIPkey")
#define addressDnsKey (@"addressDnskey")
#define addressTipKey (@"addressTipKey")



@interface ReadHostsViewController ()
{
    NSTextView* _testView;
    NSButton*   _addDnsBtn;
    NSTextField* _nameField;
    KSPasswordField* _passwordField;
    NSButton*   _openDnsBtn;
    NSMutableArray * _hostsList;
    
//    NSScrollView * _scrollView;
}
@end

@implementation ReadHostsViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do view setup here.
    
//    NSLog(@"长宽  %f %f",self.view.frame.size.width,self.view.frame.size.height);
    
//    if(!_scrollView){
//        _scrollView=[[NSScrollView alloc] initWithFrame:CGRectMake(20, 20, self.view.frame.size.width-20*2, self.view.frame.size.height-20*2-60)];
//         [self.view addSubview:_scrollView];
//        _scrollView.hasHorizontalScroller=YES;
//         _scrollView.hasVerticalScroller=YES;
//    }
    
    if (!_testView) {
        _testView=[[NSTextView alloc] initWithFrame:CGRectMake(20, 20, self.view.frame.size.width-20*2, self.view.frame.size.height-20*2-100)];
        [self.view addSubview:_testView];
    }
    _testView.frame=CGRectMake(20, 20, self.view.frame.size.width-20*2, self.view.frame.size.height-20*2-100);
    
    if (!_addDnsBtn) {
        _addDnsBtn=[[NSButton alloc] initWithFrame:CGRectMake(self.view.frame.size.width-150-20,self.view.frame.size.height-40-20-32-5, 150,32)];
        [self.view addSubview:_addDnsBtn];
        [_addDnsBtn setTitle:@"登录绑定ht的host"];
        [_addDnsBtn  setTarget:self];
        [_addDnsBtn setAction:@selector(buttonClick:)];
        _addDnsBtn.bezelStyle=NSTexturedSquareBezelStyle;
    }
    _addDnsBtn.frame=CGRectMake(self.view.frame.size.width-150-20,self.view.frame.size.height-40-20-32-5, 150,32);

    
    if (!_openDnsBtn) {
        _openDnsBtn=[[NSButton alloc] initWithFrame:CGRectMake(self.view.frame.size.width-150-20,self.view.frame.size.height-40-14,150,32)];
        [self.view addSubview:_openDnsBtn];
        [_openDnsBtn setTitle:@"一键打开hosts"];
        [_openDnsBtn  setTarget:self];
        [_openDnsBtn setAction:@selector(openButtonClick:)];
        _openDnsBtn.bezelStyle=NSTexturedSquareBezelStyle;
    }
     _openDnsBtn.frame=CGRectMake(self.view.frame.size.width-150-20,self.view.frame.size.height-40-14,150,32);
    
    if (!_nameField) {
        _nameField=[[NSTextField alloc] initWithFrame:CGRectMake(20,self.view.frame.size.height-32-20,150,32)];
        [self.view addSubview:_nameField];
      
#if __MAC_OS_X_VERSION_MAX_ALLOWED >= __MAC_10_10
         _nameField.placeholderString = @"请输入用户名";
#endif
        _nameField.bezelStyle=NSTextFieldRoundedBezel;
        [_nameField setAlignment:NSCenterTextAlignment];

    }
    
    if (!_passwordField) {
        _passwordField=[[KSPasswordField alloc] initWithFrame:CGRectMake(20,self.view.frame.size.height-32-20-14-32,150,32)];
        [self.view addSubview:_passwordField];
#if __MAC_OS_X_VERSION_MAX_ALLOWED >= __MAC_10_10
         _passwordField.placeholderString = @"请输入密码";
#endif
        _passwordField.bezelStyle=NSTextFieldRoundedBezel;
        [_passwordField setAlignment:NSCenterTextAlignment];
    }

    if (!_hostsList) {
        _hostsList=[[NSMutableArray alloc] initWithCapacity:0];
    }else{
        [_hostsList removeAllObjects];
    }
    [self showTip:@"请登录校验绑定ht的host！"];
    
}




-(void)openButtonClick:(id)sender{
    [self openHost];

}


-(void)buttonClick:(id)sender
{
    [self writeHosts];
    return ;
}

//提示
-(void)showTip:(NSString *)tipStr
{
    NSAttributedString* attr = [[NSAttributedString alloc] initWithString:tipStr];
    [[_testView textStorage] setAttributedString:attr];
}


#pragma mark -
//加载host数据列表
-(NSString*)loadHostsList{
    NSError *error;
    NSString *allTheLines = [NSString stringWithContentsOfFile:@"/private/etc/hosts"
                                                      encoding:NSUTF8StringEncoding
                                                         error:&error];
    if (error != nil) {
        NSLog(@"Some freaking error: %@", error);
        [self showTip:[NSString stringWithFormat:@"程序运行出错，hosts不存在，系统命令不支持。"]];
        return nil;
    }
    return allTheLines;
}


-(NSString*)loadOldHostsStrWithOldStr:(NSString*)allTheLines
{
    NSString* readStr=@"";

    NSArray *lines = [allTheLines componentsSeparatedByCharactersInSet:
                      [NSCharacterSet newlineCharacterSet]];
//   NSLog(@"lines %lu %@",(unsigned long)lines.count,lines);
    
    for (NSString *line in lines) {
//       NSLog(@"line %@ ",line);        
        NSString* tempTestStr=[line stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
        if([tempTestStr isEqualToString:@""]){
            continue;
        }
        tempTestStr=[tempTestStr stringByReplacingOccurrencesOfString:@" " withString:@""];
//         NSLog(@"tempTestStr %@ ",tempTestStr);
        
        for(int i=0;i<_hostsList.count;i++){
            NSDictionary * tempDci=[_hostsList objectAtIndex:i];
            NSString* addressIP=[tempDci valueForKey:addressIPKey];
            NSString* addressDns=[tempDci valueForKey:addressDnsKey];
 
            NSRange range0 = [tempTestStr rangeOfString:@"#"];   //已经注释掉
            NSRange range1 = [tempTestStr rangeOfString:[NSString stringWithFormat:@"%@%@",addressIP,addressDns]];  //无注释下一位是空
            NSRange range2 = [tempTestStr rangeOfString:[NSString stringWithFormat:@"%@%@#",addressIP,addressDns]]; //有注释下一位是#
            
            NSRange range3 = [tempTestStr rangeOfString:[NSString stringWithFormat:@"%@",addressDns]];  //无注释下一位是空
            NSRange range4 = [tempTestStr rangeOfString:[NSString stringWithFormat:@"%@#",addressDns]]; //有注释下一位是#
            
                
     if((!(range0.length>0 && (range0.location==0))) && ((range2.length>0) || (range1.length>0 && (range1.length==tempTestStr.length)))){   //已经存在
         [_hostsList removeObjectAtIndex:i];
         i--;
         readStr=[NSString stringWithFormat:@"%@%@\n",readStr,line];
         
//         NSLog(@"存在删除 %@ %@",addressIP,addressDns);
         break;
      } else if((!(range0.length>0 && (range0.location==0))) &&  ((range4.length>0) || (range3.length>0 && ((range3.location+range3.length)==tempTestStr.length)))){ //存在域名，ip不同，则屏蔽
          readStr=[NSString stringWithFormat:@"%@#%@\n",readStr,line];
           break;
      }
      if (i==(_hostsList.count-1)) { //只要域名不同都添加
          readStr=[NSString stringWithFormat:@"%@%@\n",readStr,line];
        }
            
       }
    }
    
    if([readStr isEqualToString:@""])
    {
        return nil;
    }

    return readStr;
}

-(void)writeHosts{
    [_hostsList removeAllObjects];  //整理数据
    
    NSMutableDictionary * tempDci0=[[NSMutableDictionary alloc] init];
    [tempDci0 setValue:@"11.11.11.11" forKey:addressIPKey];
    [tempDci0 setValue:@"aa.ss.4.ff" forKey:addressDnsKey];
    [tempDci0 setValue:@"#gkp测试" forKey:addressTipKey];
    
    NSMutableDictionary * tempDci1=[[NSMutableDictionary alloc] init];
    [tempDci1 setValue:@"11.23.22.23" forKey:addressIPKey];
    [tempDci1 setValue:@"hu.lin.com" forKey:addressDnsKey];
    [tempDci1 setValue:@"#HT" forKey:addressTipKey];
    
    [_hostsList addObject:tempDci0];
    [_hostsList addObject:tempDci1];
 
    NSString* allTheLines=[self loadHostsList];
    if (!allTheLines) {
        [self showTip:@"程序运行出错，读取hosts失败，系统命令不支持。"];
        return;
    }

    if(_hostsList.count==0){    //一开始就没数据 则该用户无host数据
        [self showTip:@"没有host数据绑定！"];
        return;
    }

    NSString* readStr=[self loadOldHostsStrWithOldStr:allTheLines]; //被改变
    if(_hostsList.count==0){    //说明都存在了
        [self showTip:@"host数据已经存在！"];
        return;
    }
    
    //设置该添加的数据
//        NSLog(@"添加 _hostsList %@",_hostsList);
    for(int i=0;i<_hostsList.count;i++){
        NSDictionary * tempDci=[_hostsList objectAtIndex:i];
        NSString* addressIP=[tempDci valueForKey:addressIPKey];
        NSString* addressDns=[tempDci valueForKey:addressDnsKey];
        NSString* addressTip=[tempDci valueForKey:addressTipKey];
        
        if (readStr) {
            readStr=[NSString stringWithFormat:@"%@\n%@  %@  %@",readStr,addressIP,addressDns,addressTip];
        }else{
            readStr=[NSString stringWithFormat:@"%@  %@  %@",addressIP,addressDns,addressTip];
        }
        
    }
    
    NSLog(@"添加 readStr %@",readStr);

    //添加
    NSString *convertedPath = [NSString stringWithUTF8String:[@"/etc/hosts" UTF8String]];
    NSTask *task = [[NSTask alloc] init];
    NSPipe *pipe = [[NSPipe alloc] init];
    
    [task setLaunchPath:@"/usr/libexec/authopen"];
    [task setArguments:[NSArray arrayWithObjects:@"-c", @"-w", convertedPath, nil]];
    [task setStandardInput:pipe];

    BOOL isError=NO;
    
    @try {
        [task launch];
    }
    @catch (NSException *exception) {
        isError=YES;
        [self showTip:[NSString stringWithFormat:@"程序运行出错，系统命令不支持。"]];
    }
    @finally {
    }
    if (isError) {
        return;
    }

    NSData* stringData  = [readStr dataUsingEncoding:NSUTF8StringEncoding];
    NSFileHandle *writeHandle = [pipe fileHandleForWriting];
    [writeHandle writeData:stringData];
    close([writeHandle fileDescriptor]); // Close it manually
    [writeHandle setValue:[NSNumber numberWithUnsignedShort:1] forKey:@"_flags"];
    [task waitUntilExit];

    [self showTip:@"已经添加完毕host数据"];
}


-(void)openHost{
    NSString *convertedPath = [NSString stringWithUTF8String:[@"/etc/hosts" UTF8String]];
    NSTask *task = [[NSTask alloc] init];
    NSPipe *pipe = [[NSPipe alloc] init];
    [task setLaunchPath:@"/usr/bin/open"];
    [task setArguments:[NSArray arrayWithObjects:convertedPath, nil]];
    [task setStandardInput:pipe];
    @try {
        [task launch];
    }
    @catch (NSException *exception) {
        [self showTip:[NSString stringWithFormat:@"程序运行出错，打开hosts失败，系统命令不支持。"]];
    }
    @finally {

    }
}

@end
