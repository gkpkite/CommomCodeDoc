//
//  ViewController.m
//  test03
//
//  Created by kitegkp on 15/4/13.
//  Copyright (c) 2015年 kitegkp. All rights reserved.
//

#import "ViewController.h"
#import "TSPeiXunViewController.h"
#import <JavaScriptCore/JavaScriptCore.h>
#import "TempView.h"

@interface ViewController ()<UIWebViewDelegate>{

    IBOutlet UIWebView *_webView;
    
    UIWebView *_webViewtemp;
    TempView * _tempView;
    
//    UIView * _tempViewtr;
}
- (IBAction)btnClick:(id)sender;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.

    
    
    _webViewtemp=[[UIWebView alloc]initWithFrame:CGRectMake(0, 310, self.view.bounds.size.width, 300)];
    _webViewtemp.backgroundColor=[UIColor lightGrayColor];
    NSString *htmlPath=[[NSBundle mainBundle] resourcePath];
    htmlPath=[htmlPath stringByAppendingPathComponent:@"h.html"];
    NSURL *localURL=[[NSURL alloc]initFileURLWithPath:htmlPath];
        _webViewtemp.delegate=self;
    [_webViewtemp loadRequest:[NSURLRequest requestWithURL:localURL]];
    [self.view addSubview:_webViewtemp];


    //JS 传过来
    


//    //oc 调用js
//    
//    //测试
//    _tempView=[[TempView alloc] init];
//    _tempView.view.frame=CGRectMake(100, 100, 200, 300);
//    [_tempView.view setBackgroundColor:[UIColor yellowColor]];
//    [self.view addSubview:_tempView.view];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


//获取顶层控制器
-(UIViewController *)getTopController{
    UIViewController * vc =  [[UIApplication sharedApplication] keyWindow].rootViewController;
    UIViewController *topControllerNext=[vc presentedViewController];
    UIViewController *topController=vc;
    while (topControllerNext) {
        topController=topControllerNext;
        topControllerNext=[topControllerNext presentedViewController];
    }
    return topController;
}


- (IBAction)btnClick:(id)sender {
    
}


// 功能：UIWebView响应长按事件
-(BOOL)webView:(UIWebView *)webView shouldStartLoadWithRequest:(NSURLRequest *)_request navigationType:(UIWebViewNavigationType)navigationType
{
    
    NSString *requestString = [[[_request URL] absoluteString]stringByReplacingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    NSString* str=@"action://";
    //判断如果是js调用oc 命令时候
    if([requestString rangeOfString:str].location!=NSNotFound)
    {
        NSRange range = [str rangeOfString:str];
        if (range.length==str.length && (range.location==0)) { //最后一个是图片时候，直接省略号
            requestString = [requestString substringFromIndex:str.length];  //从有表情标号开始
        }
        [self performAction:requestString];
        return NO; //执行调用返回No
    }


    return YES;  //非js调用时候，正常返回yes
}

#pragma mark- js 返回事件

//{"action":"confirm","options":{"title":"培训报名","message":"哇，对这个培训有兴趣，确定报名？"},"callback":"callback_931100"}
//执行html事件

/*
 这个字符串可以随意写，相应统一前后台解析就行了。
 
"action":"confirm"    命令标志confirm打开对话框
options  是附加参数
"callback":"callback_931100" 参数是传给oc这边告诉执行完命令后，可以调的js方法
*/

-(void)performAction:(NSString*)actionJson
{
    id json = [NSJSONSerialization JSONObjectWithData:[actionJson dataUsingEncoding:NSUTF8StringEncoding] options:NSJSONReadingAllowFragments error:nil];
    if (![json  isKindOfClass:[NSDictionary class]]) {
        return;
    }
    NSString * action=[json valueForKey:@"action"];
    NSString * callback=[json valueForKey:@"callback"];
//    NSDictionary * options=[json valueForKey:@"options"];
    if ([action isEqualToString:@"confirm"]) {  //执行的命令1
        //输出对话框 。。。。
        
        //然后回调js 方法
        //oc调js的方法------- callback_931100
        NSString *jsCode = [NSString stringWithFormat:@"javascript:%@()",callback];
        [_webViewtemp stringByEvaluatingJavaScriptFromString:jsCode];
        //oc调js的方法-------
        
    }
    else if([action isEqualToString:@"alert"]){  //或者执行的命令2 。。。
      
    }
    else if([action isEqualToString:@"prompt"]){ //或者执行的命令3 。。。
       
    }
    else if([action isEqualToString:@"back"]){

    }
}





-(void)openFn{
    NSLog(@"of");
}

@end
