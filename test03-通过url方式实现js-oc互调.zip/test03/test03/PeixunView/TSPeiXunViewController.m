//
//  TSPeiXunViewController.m
//  ThreeSevenAssistant
//
//  Created by kitegkp on 15/4/13.
//  Copyright (c) 2015年 37. All rights reserved.
//

#import "TSPeiXunViewController.h"



@interface TSPeiXunViewController ()
{

    IBOutlet UIButton *_backBtn;
    IBOutlet UIView *_topView;
    IBOutlet UILabel *_titleLable;
    IBOutlet UIView *_userView;
    IBOutlet UIView *_leibieView;
    IBOutlet UIView *_contentView;
    UIView *_tipView;
    IBOutlet UIView *_canXunJiLu;
    IBOutlet UIView *_qingJiaJiLu;
    IBOutlet UILabel *_canXunJiFen;
    IBOutlet UILabel *_canXunTip;
    IBOutlet UIImageView *_canXunImg;
    IBOutlet UIImageView *_qingJiaImg;
    
}
- (IBAction)clickBackBtn:(id)sender;

@end

@implementation TSPeiXunViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
//   [self layoutSubViews];
    _canXunImg.hidden=YES;
    _qingJiaImg.hidden=YES;
    
    [self initSubViews];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

-(void)initSubViews{
    /*
    //参训记录
    UITapGestureRecognizer *canXunJiLuTapGesture=[[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(jiLuSelTapGesture:)];
    [_canXunJiLu addGestureRecognizer:canXunJiLuTapGesture];

    //请假记录
    UITapGestureRecognizer *qingJiaJiLuTapGesture=[[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(jiLuSelTapGesture:)];
    [_qingJiaJiLu addGestureRecognizer:qingJiaJiLuTapGesture];
     */

}


-(void)jiLuSelTapGesture:(UIGestureRecognizer*)ges
{
     if (ges.view==_canXunJiLu)
     {
         [self showCanXunJiLu];
     }else if(ges.view==_qingJiaJiLu)
     {
         [self showQingJiaImg];
     }
}

//显示参训记录
-(void)showCanXunJiLu
{
    _canXunImg.hidden=NO;
    _qingJiaImg.hidden=YES;
    [self showTip:@"没有参加培训信息."];
}

-(void)showTip:(NSString *)tipStr{

}

//显示参训记录
-(void)showQingJiaImg
{
    _canXunImg.hidden=YES;
    _qingJiaImg.hidden=NO;
    [self showTip:@"我是三好学生，从不缺勤！"];
}



//布局时候调整位置
- (void)viewDidLayoutSubviews{

}


//返回
- (IBAction)clickBackBtn:(id)sender {
    [[UIApplication sharedApplication] setStatusBarHidden:YES];
    [self.navigationController popViewControllerAnimated:YES];
}
@end
