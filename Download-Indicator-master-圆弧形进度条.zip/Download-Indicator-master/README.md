Download-Indicator
==================

This is a iOS Download Indicator for iOS 7, which can be used for showing the download % of the files being downloaded. It contains 3 types of indicators (closed, filled and mixed).

The classes are made flexible such that

* Change the stroke color.
* Changefill color.
* Custom set the inner and the outer radius, the animation duration.

Here a image in the gif format, but in real the indicator animates beautifully from one state to another.


![](http://s2.postimg.org/l3hnef3t5/RMDownload_Indicator.gif)
