//
//  RMViewController.m
//  RMLoaderDisplay
//
//  Created by Mahesh on 1/30/14.
//  Copyright (c) 2014 Mahesh Shanbhag. All rights reserved.
//

#import "RMViewController.h"
#import "RMDownloadIndicator.h"

@interface RMViewController ()
{
    float _orgX;
    NSTimer * _codeTimer;

}
@property (weak, nonatomic) IBOutlet UILabel *settings;
@property (weak, nonatomic) IBOutlet UISwitch *settingSwitch;

@property (weak, nonatomic) RMDownloadIndicator *closedIndicator;
@property (weak, nonatomic) RMDownloadIndicator *filledIndicator;
@property (weak, nonatomic) RMDownloadIndicator *mixedIndicator;

@property (assign, nonatomic)CGFloat downloadedBytes;

@end

@implementation RMViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    _orgX=10;
	// Do any additional setup after loading the view, typically from a nib.
   // [self settingChanged:self.settingSwitch];
    
    if (!_codeTimer) {
        _codeTimer = [NSTimer scheduledTimerWithTimeInterval:0.01f target:self selector:@selector(codeTimerFired:) userInfo:nil repeats:YES];
    }
//   [_codeTimer setFireDate:[NSDate distantFuture]];
//     [_closedIndicator setIndicatorAnimationDuration:0.1];
    [self addDownloadIndicators];
    //不断设置进程
//    [self codeTimerFired:_codeTimer];
//     [_codeTimer setFireDate:[NSDate date]];
    
//    [self updateViewOneTime];

}





- (void)codeTimerFired:(NSTimer *) timer    //相差0
{
    
    NSTimeInterval fTime = [[[NSDate alloc] initWithTimeIntervalSinceNow:0] timeIntervalSince1970];
    NSInteger secTime = (NSInteger) fTime;
    //    double progress = (fTime - secTime + secTime%30)/30.0;
    float progress=0;
    progress=secTime%30;
    
    if (progress==0) {
        [self addDownloadIndicators];

    }
    
//    typeof(self) __weak weakself = self;
//    double delayInSeconds = 1;
//    dispatch_time_t popTime = dispatch_time(DISPATCH_TIME_NOW, (int64_t)(delayInSeconds * NSEC_PER_SEC));
//    dispatch_after(popTime, dispatch_get_main_queue(), ^(void){
//        
//        NSLog(@"progress %f %f",progress,progress/30.00000);
//            [_closedIndicator updateProgress:progress/30.00000];
//    });
//    
//    
//    if (progress==30) {
//        double delayInSeconds4 = delayInSeconds+1;
//        dispatch_time_t popTime0 = dispatch_time(DISPATCH_TIME_NOW, (int64_t)(delayInSeconds4 * NSEC_PER_SEC));
//        dispatch_after(popTime0, dispatch_get_main_queue(), ^(void){
//            
//            [_codeTimer setFireDate:[NSDate distantFuture]];
//            [weakself addDownloadIndicators];
//           // [weakself updateViewOneTime];
//             [_codeTimer setFireDate:[NSDate date]];
//        });
//    }
    
    
}



- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)addDownloadIndicators
{
    [_closedIndicator removeFromSuperview];
    _closedIndicator = nil;
    
    _orgX=_orgX+10;
    
    RMDownloadIndicator *closedIndicator = [[RMDownloadIndicator alloc]initWithFrame:CGRectMake(10, CGRectGetMaxY(self.settingSwitch.frame) + 60.0f, 180, 180) ];
    [closedIndicator setBackgroundColor:[UIColor whiteColor]];
//    [closedIndicator setFillColor:[UIColor colorWithRed:16./255 green:119./255 blue:234./255 alpha:1.0f]];
    [closedIndicator setStrokeColor:[UIColor colorWithRed:16./255 green:119./255 blue:234./255 alpha:1.0f]];
    [self.view addSubview:closedIndicator];
    [closedIndicator loadIndicator];
    _closedIndicator = closedIndicator;
    
    
    NSTimeInterval fTime = [[[NSDate alloc] initWithTimeIntervalSinceNow:0] timeIntervalSince1970];
    NSInteger secTime = (NSInteger) fTime;
    float progress=0;
    progress=secTime%30;
    
    [_closedIndicator setIndicatorAnimationDuration:30.0-progress];
    [_closedIndicator updateProgress:1];
    
    
 //   [_codeTimer setFireDate:[NSDate date]];
    
    
//    RMDownloadIndicator *filledIndicator = [[RMDownloadIndicator alloc]initWithFrame:CGRectMake((CGRectGetWidth(self.view.bounds) - 80)/2, CGRectGetMaxY(self.closedIndicator.frame) + 40.0f , 80, 80) type:kRMFilledIndicator];
//    [filledIndicator setBackgroundColor:[UIColor whiteColor]];
//    [filledIndicator setFillColor:[UIColor colorWithRed:16./255 green:119./255 blue:234./255 alpha:1.0f]];
//    [filledIndicator setStrokeColor:[UIColor colorWithRed:16./255 green:119./255 blue:234./255 alpha:1.0f]];
//    filledIndicator.radiusPercent = 0.45;
//    [self.view addSubview:filledIndicator];
//    [filledIndicator loadIndicator];
//    _filledIndicator = filledIndicator;
//    
//    RMDownloadIndicator *mixedIndicator = [[RMDownloadIndicator alloc]initWithFrame:CGRectMake((CGRectGetWidth(self.view.bounds) - 80)/2, CGRectGetMaxY(self.filledIndicator.frame) + 40.0f, 80, 80) type:kRMMixedIndictor];
//    [mixedIndicator setBackgroundColor:[UIColor whiteColor]];
//    [mixedIndicator setFillColor:[UIColor colorWithRed:16./255 green:119./255 blue:234./255 alpha:1.0f]];
//    [mixedIndicator setStrokeColor:[UIColor colorWithRed:16./255 green:119./255 blue:234./255 alpha:1.0f]];
//    mixedIndicator.radiusPercent = 0.45;
//    [self.view addSubview:mixedIndicator];
//    [mixedIndicator loadIndicator];
//    _mixedIndicator = mixedIndicator;
}


#pragma mark - Update Views
- (void)startAnimation
{
    [self addDownloadIndicators];
    
//    if(!self.settingSwitch.isOn)
//    {
//        [self updateViewOneTime];
//        return;
//    }
    
    self.downloadedBytes = 0;
    
    
    self.settingSwitch.userInteractionEnabled = NO;
    typeof(self) __weak weakself = self;
    double delayInSeconds = 1;
    dispatch_time_t popTime = dispatch_time(DISPATCH_TIME_NOW, (int64_t)(delayInSeconds * NSEC_PER_SEC));
    dispatch_after(popTime, dispatch_get_main_queue(), ^(void){
        [weakself updateView:10.0f];
    });
    
    double delayInSeconds1 = delayInSeconds + 1;
    dispatch_time_t popTime1 = dispatch_time(DISPATCH_TIME_NOW, (int64_t)(delayInSeconds1 * NSEC_PER_SEC));
    dispatch_after(popTime1, dispatch_get_main_queue(), ^(void){
        [weakself updateView:30.0f];
    });
    
    double delayInSeconds2 = delayInSeconds1 + 1;
    dispatch_time_t popTime2 = dispatch_time(DISPATCH_TIME_NOW, (int64_t)(delayInSeconds2 * NSEC_PER_SEC));
    dispatch_after(popTime2, dispatch_get_main_queue(), ^(void){
        [weakself updateView:10.0f];
    });
    
    double delayInSeconds3 = delayInSeconds2 + 1;
    dispatch_time_t popTime3 = dispatch_time(DISPATCH_TIME_NOW, (int64_t)(delayInSeconds3 * NSEC_PER_SEC));
    dispatch_after(popTime3, dispatch_get_main_queue(), ^(void){
        [weakself updateView:50.0f];
        self.settingSwitch.userInteractionEnabled = YES;
    });
    double delayInSeconds4 = delayInSeconds3+1;
    dispatch_time_t popTime0 = dispatch_time(DISPATCH_TIME_NOW, (int64_t)(delayInSeconds4 * NSEC_PER_SEC));
    dispatch_after(popTime0, dispatch_get_main_queue(), ^(void){
        [weakself startAnimation];
    });
    
}

- (void)updateView:(CGFloat)val
{
    self.downloadedBytes+=val;
    [_closedIndicator updateProgress:self.downloadedBytes/100];
//    [_closedIndicator updateWithTotalBytes:100 downloadedBytes:self.downloadedBytes];
//    [_filledIndicator updateWithTotalBytes:100 downloadedBytes:self.downloadedBytes];
//    [_mixedIndicator updateWithTotalBytes:100 downloadedBytes:self.downloadedBytes];
}

- (void)updateViewOneTime
{
    //设置时间段结束
    NSTimeInterval fTime = [[[NSDate alloc] initWithTimeIntervalSinceNow:0] timeIntervalSince1970];
    NSInteger secTime = (NSInteger) fTime;
    //    double progress = (fTime - secTime + secTime%30)/30.0;
    float progress=0;
    progress=secTime%30;
    
    double delayInSeconds = 1;
    dispatch_time_t popTime = dispatch_time(DISPATCH_TIME_NOW, (int64_t)(delayInSeconds * NSEC_PER_SEC));
    dispatch_after(popTime, dispatch_get_main_queue(), ^(void){
        
//        NSLog(@"progress %f %f",progress,progress/30.00000);
////        [_closedIndicator setIndicatorAnimationDuration:0.01];
//        [_closedIndicator updateProgress:progress/30.00000];
        
        [_closedIndicator setIndicatorAnimationDuration:30.0-progress];
        [_closedIndicator updateProgress:1];
    });
}

#pragma mark - Switch Change
- (IBAction)settingChanged:(UISwitch *)sender
{
    if(self.settingSwitch.isOn)
    {
        [self.settings setText:@"Multi Time Animation"];
       // [self startAnimation];
    }
    else
    {
        [self.settings setText:@"One Time Animation"];
    // [self startAnimation];
      //  [self updateViewOneTime];
    }
}

@end
