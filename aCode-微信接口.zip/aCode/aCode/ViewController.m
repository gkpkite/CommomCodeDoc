//
//  ViewController.m
//  aCode
//
//  Created by kitegkp on 15/7/30.
//  Copyright (c) 2015年 kitegkp. All rights reserved.
//

#import "ViewController.h"
#import "WXApi.h"

@interface ViewController ()
{
    UIButton * _but;
    UIButton * _but0;

}
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    [self.view setBackgroundColor:[UIColor brownColor]];
    
    
    //   [[UIApplication sharedApplication] openURL:[NSURL URLWithString:temp]];
    if (!_but) {
        _but=[[UIButton alloc] initWithFrame:CGRectMake(100, 100, 200, 100)];
        [self.view addSubview:_but];
        [_but setTitle:@"分享朋友" forState:UIControlStateNormal];
        [ _but addTarget:self action:@selector(test:) forControlEvents:UIControlEventTouchUpInside];
    }
    
    if (!_but0) {
        _but0=[[UIButton alloc] initWithFrame:CGRectMake(100, 300, 200, 100)];
        [self.view addSubview:_but0];
        [_but0 setTitle:@"分享朋友圈" forState:UIControlStateNormal];
        [ _but0 addTarget:self action:@selector(test1:) forControlEvents:UIControlEventTouchUpInside];
    }

    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)test:(id)sendr{
//    NSString * backStr=@"back=aa";
//    NSString *urlStr=[NSString stringWithFormat:@"bb://%@",backStr];
//    [[UIApplication sharedApplication] openURL:[NSURL URLWithString:urlStr]];
    WXMediaMessage *message = [[WXMediaMessage alloc] init];
    message.title = @"pengyou";
    message.description = @"fenxiang";
    
    WXWebpageObject *webpageObj = [[WXWebpageObject alloc] init];
    webpageObj.webpageUrl = @"http://www.163.com/";;
    message.mediaObject = webpageObj;
    message.mediaTagName = @"WECHAT_SQTOKEN_DOWNLOAD";
    
    SendMessageToWXReq *req = [[SendMessageToWXReq alloc] init];
    req.bText = NO;
    req.message = message;
    req.scene = WXSceneSession;
    [WXApi sendReq:req];
}

-(void)test1:(id)sendr{
//    [[UIApplication sharedApplication] openURL:[NSURL URLWithString:@"bb://"]];

        if (![WXApi isWXAppInstalled]) {
            return;
        }
        
        WXMediaMessage *message = [[WXMediaMessage alloc] init];
        message.title = @"测试分享";
        message.description = @"分享测试";

        
        WXWebpageObject *webpageObj = [[WXWebpageObject alloc] init];
        webpageObj.webpageUrl =@"http://www.baidu.com/";
        message.mediaObject = webpageObj;
        message.mediaTagName = @"WECHAT_SQTOKEN_DOWNLOAD";
        
        SendMessageToWXReq *req = [[SendMessageToWXReq alloc] init];
        req.bText = NO;
        req.message = message;
        req.scene = WXSceneTimeline;
        [WXApi sendReq:req];

}

@end
