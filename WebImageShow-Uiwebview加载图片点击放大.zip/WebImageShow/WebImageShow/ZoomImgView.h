//
//  ZoomImgView.h
//  WebImageShow
//
//  Created by kitegkp on 15/7/11.
//  Copyright (c) 2015年 BW. All rights reserved.
//

#import <UIKit/UIKit.h>
@class ZoomImgView;
@protocol ZoomImgViewDelegate <UIScrollViewDelegate>
-(void)exitZoomImgView:(ZoomImgView*)zoomImgView;

@end

@interface ZoomImgView : UIScrollView

-(void)setImgViewWithUrl:(NSString*)urlStr;

@property (nonatomic, assign) id <ZoomImgViewDelegate> zoomImgDelegate;

@end
