//
//  ShowViewController.m
//  WebImageShow
//
//  Created by iZ on 13-8-30.
//  Copyright (c) 2013年 BW. All rights reserved.

// ARC 工程 
//iOS 中国开发者 QQ：262091386  欢迎加入交流

#import "ShowViewController.h"
#import "UIImageView+WebCache.h"
#import "ZoomImgView.h"

@interface ShowViewController ()<UIGestureRecognizerDelegate,UIScrollViewDelegate,ZoomImgViewDelegate>

@property (nonatomic,retain) UIWebView *showWebView;

@end

@implementation ShowViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        self.title = @"点击查看网页中图片";
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
    _showWebView = [[UIWebView alloc] initWithFrame:CGRectMake(0, 0, 320, 460-44)];
    NSURLRequest *urlRequest = [NSURLRequest requestWithURL:[NSURL URLWithString:@"http://37hwapp.37.com/index.php?c=article&a=view&aid=1032&from=singlemessage&isappinstalled=1"]];
    [_showWebView loadRequest:urlRequest];
    [self.view addSubview:_showWebView];
    
    [self addTapOnWebView];
 }

-(void)addTapOnWebView
{
    UITapGestureRecognizer* singleTap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(handleSingleTap:)];
    [self.showWebView addGestureRecognizer:singleTap];
    singleTap.delegate = self;
    singleTap.cancelsTouchesInView = NO;
}

#pragma mark- TapGestureRecognizer

- (BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer shouldRecognizeSimultaneouslyWithGestureRecognizer:(UIGestureRecognizer *)otherGestureRecognizer
{
    return YES;
}

-(void)handleSingleTap:(UITapGestureRecognizer *)sender
{
    CGPoint pt = [sender locationInView:self.showWebView];
    NSString *imgURL = [NSString stringWithFormat:@"document.elementFromPoint(%f, %f).src", pt.x, pt.y];

    
    NSString *urlToSave = [self.showWebView stringByEvaluatingJavaScriptFromString:imgURL];
    NSLog(@"image url=%@", urlToSave);
    if (urlToSave.length > 0) {
        [self showImageURL:urlToSave point:pt];
    }
}

//呈现图片
-(void)showImageURL:(NSString *)url point:(CGPoint)point
{
    
    ZoomImgView * tempImgView=[[ZoomImgView alloc] initWithFrame:CGRectMake(0, 0,self.view.frame.size.width,self.view.frame.size.height)];
    [self.view addSubview:tempImgView];
    tempImgView.center = self.view.center;
     [tempImgView setBackgroundColor:[UIColor lightGrayColor]];
    tempImgView.zoomImgDelegate=self;
    [tempImgView setImgViewWithUrl:url];

    return;
//    
//    
//    
//    UIView * backView=[[UIView alloc] initWithFrame:CGRectMake(0, 0,self.view.frame.size.width,self.view.frame.size.height)];
//    [self.view addSubview:backView];
//    
//    [backView setBackgroundColor:[UIColor lightGrayColor]];
//    
//    UIImageView *showView = [[UIImageView alloc] init];
////    showView.center = point;
////    [UIView animateWithDuration:0.5f animations:^{
////        CGPoint newPoint = self.view.center;
////        newPoint.y += 20;
////        showView.center = newPoint;
////    }];
//    
//    showView.backgroundColor = [UIColor blackColor];
////    showView.alpha = 0.9;
//    showView.userInteractionEnabled = YES;
////    [self.view addSubview:showView];
////    [showView setImageWithURL:[NSURL URLWithString:url]];
//    
//    UIScrollView * imgScrollView=[[UIScrollView alloc] init];
//    [imgScrollView setBackgroundColor:[UIColor yellowColor]];
////    imgScrollView.userInteractionEnabled=YES;
//    showView.userInteractionEnabled=YES;
////    backView.userInteractionEnabled=YES;
////    self.view.userInteractionEnabled=YES;
//    imgScrollView.delegate=self;
//    
//    [backView addSubview:imgScrollView];
//    [imgScrollView addSubview:showView];
//    
//    
////    UITapGestureRecognizer *singleTapOne1 = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(palyBtnVieSingleTap:)];
////    singleTapOne1.numberOfTouchesRequired = 1;
////    singleTapOne1.numberOfTapsRequired = 1;
////    singleTapOne1.delegate = self;
////    [imgScrollView addGestureRecognizer:singleTapOne1];
//    
//    
//    __block typeof(showView) showViewTemp=showView;
//    __block typeof(self) selfTemp=self;
//    __block typeof(imgScrollView) imgScrollViewTemp=imgScrollView;
//    
//    [showView setImageWithURL:[NSURL URLWithString:url] placeholderImage:nil completed:^(UIImage *image,NSError *error,SDImageCacheType cacheType)
//     {
//         NSLog(@"image.size.width %f image.size.height %f",image.size.width,image.size.height);
//         float height=0;
//         height =selfTemp.view.frame.size.width/(image.size.width/image.size.height);
//         imgScrollViewTemp.frame=CGRectMake(0, 0,selfTemp.view.frame.size.width,selfTemp.view.frame.size.height);
//         imgScrollViewTemp.center = selfTemp.view.center;
//         
//
//         
//         // The imageView can be zoomed largest size
//         showViewTemp.frame = CGRectMake(0, 0,selfTemp.view.frame.size.width,height);
//         showViewTemp.userInteractionEnabled = YES;
//        showViewTemp.center = imgScrollViewTemp.center;
//         
//         float minimumScale =imgScrollViewTemp.frame.size.width/showViewTemp.frame.size.width;
//         NSLog(@"minimumScale %f",minimumScale);
//         [imgScrollViewTemp setMinimumZoomScale:1];
//          NSLog(@"setMaximumZoomScale %f",showViewTemp.frame.size.width/imgScrollViewTemp.frame.size.width);
//         [imgScrollViewTemp setMaximumZoomScale:4];
//         [imgScrollViewTemp setZoomScale:minimumScale];
//         
//         
//     }];
//    
//    
//    UITapGestureRecognizer* singleTap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(handleSingleViewTap:)];
//    [showView addGestureRecognizer:singleTap];
//    
//    [self.navigationController setNavigationBarHidden:YES animated:YES];
}

- (void)palyBtnVieSingleTap:(UITapGestureRecognizer *)recognizer
{
    NSLog(@"点击点击");
}

- (UIView *)viewForZoomingInScrollView:(UIScrollView *)scrollView
{
    UIView * tempImg=[[scrollView subviews] objectAtIndex:0];
    
    return tempImg;
}

- (void)scrollViewDidEndZooming:(UIScrollView *)scrollView withView:(UIView *)view atScale:(CGFloat)scale
{
    NSLog(@"scale %f",scale);
    [scrollView setZoomScale:scale animated:NO];
}
//让图片居中
- (void)scrollViewDidZoom:(UIScrollView *)scrollView
{
    UIView * tempImg=[[scrollView subviews] objectAtIndex:0];
    
    // tempImg.center = aScrollView.center;
    
        CGFloat offsetX = (scrollView.bounds.size.width > scrollView.contentSize.width)?
        (scrollView.bounds.size.width - scrollView.contentSize.width) * 0.5 : 0.0;
        CGFloat offsetY = (scrollView.bounds.size.height > scrollView.contentSize.height)?
        (scrollView.bounds.size.height - scrollView.contentSize.height) * 0.5 : 0.0;
        tempImg.center = CGPointMake(scrollView.contentSize.width * 0.5 + offsetX,
                                     scrollView.contentSize.height * 0.5 + offsetY);

    
}

//移除图片查看视图
-(void)handleSingleViewTap:(UITapGestureRecognizer *)sender
{    
    for (id obj in self.view.subviews) {
        if ([obj isKindOfClass:[UIImageView class]]) {
            [obj removeFromSuperview];
        }
    }
    [self.navigationController setNavigationBarHidden:NO animated:YES];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

//退出浏览器图片界面
-(void)exitZoomImgView:(ZoomImgView*)zoomImgView{

    [zoomImgView removeFromSuperview];
}

@end
