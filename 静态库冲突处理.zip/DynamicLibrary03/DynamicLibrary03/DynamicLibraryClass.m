//
//  DynamicLibraryClass.m
//  DynamicLibrary03
//
//  Created by kitegkp on 15/7/20.
//  Copyright (c) 2015年 kitegkp. All rights reserved.
//

#import "DynamicLibraryClass.h"

@implementation DynamicLibraryClass


-(void)test{
    
    NSLog(@"DynamicLibrary03===DynamicLibraryClass==test");
    
}

@end
