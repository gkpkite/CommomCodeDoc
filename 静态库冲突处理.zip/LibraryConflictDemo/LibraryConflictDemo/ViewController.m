//
//  ViewController.m
//  LibraryConflictDemo
//
//  Created by kitegkp on 15/7/20.
//  Copyright (c) 2015年 kitegkp. All rights reserved.
//

#import "ViewController.h"
#import "DynamicLibraryClass.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    DynamicLibraryClass * testObj=[[DynamicLibraryClass alloc] init];
    [testObj test];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
