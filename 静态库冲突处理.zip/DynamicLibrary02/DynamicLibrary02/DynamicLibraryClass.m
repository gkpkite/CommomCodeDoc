//
//  DynamicLibraryClass.m
//  DynamicLibrary02
//
//  Created by kitegkp on 15/7/17.
//  Copyright (c) 2015年 kitegkp. All rights reserved.
//

#import "DynamicLibraryClass.h"

@implementation DynamicLibraryClass



-(void)test{
    
    NSLog(@"DynamicLibrary02===DynamicLibraryClass==test");
    
}
@end
