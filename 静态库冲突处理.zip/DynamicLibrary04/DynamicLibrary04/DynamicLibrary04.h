//
//  DynamicLibrary04.h
//  DynamicLibrary04
//
//  Created by kitegkp on 15/7/20.
//  Copyright (c) 2015年 kitegkp. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface DynamicLibrary04 : NSObject

@end
