//
//  TempView.m
//  test03
//
//  Created by kitegkp on 15/5/25.
//  Copyright (c) 2015年 kitegkp. All rights reserved.
//

#import "TempView.h"

@implementation TempView

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)loadView
{
    [super loadView];
    UIView * tempView=[[UIView alloc] initWithFrame:CGRectMake(10, 10, 100, 100)];
    [tempView setBackgroundColor:[UIColor redColor]];
    [self.view addSubview:tempView];

}

- (void)viewDidLoad
{
    [super viewDidLoad];
}

@end
