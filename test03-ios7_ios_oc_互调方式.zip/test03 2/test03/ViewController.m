//
//  ViewController.m
//  test03
//
//  Created by kitegkp on 15/4/13.
//  Copyright (c) 2015年 kitegkp. All rights reserved.
//

#import "ViewController.h"
#import "TSPeiXunViewController.h"
#import <JavaScriptCore/JavaScriptCore.h>
#import "TempView.h"

@interface ViewController ()<UIWebViewDelegate>{

    IBOutlet UIWebView *_webView;
    
    UIWebView *_webViewtemp;
    TempView * _tempView;
    
    UIView * _tempViewtr;
}
- (IBAction)btnClick:(id)sender;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];

    
    
    _webViewtemp=[[UIWebView alloc]initWithFrame:CGRectMake(0, 310, self.view.bounds.size.width, 300)];
    _webViewtemp.backgroundColor=[UIColor lightGrayColor];
    NSString *htmlPath=[[NSBundle mainBundle] resourcePath];
    htmlPath=[htmlPath stringByAppendingPathComponent:@"h.html"];
    _webViewtemp.delegate=self;
    NSURL *localURL=[[NSURL alloc]initFileURLWithPath:htmlPath];
    [_webViewtemp loadRequest:[NSURLRequest requestWithURL:localURL]];
    [self.view addSubview:_webViewtemp];
    
 
    
    //注册oc的方法
    
    __block typeof(self) tempself= self;
    JSContext *context = [_webViewtemp valueForKeyPath:@"documentView.webView.mainFrame.javaScriptContext"];
    context[@"jakilllog"] = ^() {
        
        NSLog(@"+++++++Begin Log+++++++");
        NSArray *args = [JSContext currentArguments];
        
        for (JSValue *jsVal in args) {
            NSLog(@"%@", jsVal);
        }
        
        JSValue *this = [JSContext currentThis];
        NSLog(@"this: %@",this);
        NSLog(@"-------End Log-------");
        [tempself openFn];
        
    };

    //oc 调用js
    
    
    
    
//    //不同test颜色
//    UILabel * temp=[[UILabel alloc]initWithFrame:CGRectMake(10, 130,300, 300) ];
//    temp.backgroundColor = [UIColor lightGrayColor];
//    temp.textColor = [UIColor blackColor];
//    temp.font = [UIFont systemFontOfSize:15.f];
//     NSMutableAttributedString *attrString = [[NSMutableAttributedString alloc] initWithString:@"测试测试15813348317测试测试测试！！！"];
//    [attrString beginEditing];
//    [attrString addAttribute:NSForegroundColorAttributeName value:[UIColor redColor] range:NSMakeRange(4,11)];
//    [attrString addAttribute:NSFontAttributeName value:[UIFont systemFontOfSize:50.0f] range:NSMakeRange(4,11)];
//    [attrString endEditing];
//    temp.attributedText=attrString;
//    [self.view addSubview:temp];

//    //测试
//    _tempView=[[TempView alloc] init];
//    _tempView.view.frame=CGRectMake(100, 100, 200, 300);
//    [_tempView.view setBackgroundColor:[UIColor yellowColor]];
//    [self.view addSubview:_tempView.view];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


//获取顶层控制器
-(UIViewController *)getTopController{
    UIViewController * vc =  [[UIApplication sharedApplication] keyWindow].rootViewController;
    UIViewController *topControllerNext=[vc presentedViewController];
    UIViewController *topController=vc;
    while (topControllerNext) {
        topController=topControllerNext;
        topControllerNext=[topControllerNext presentedViewController];
    }
    return topController;
}


- (IBAction)btnClick:(id)sender {

    
}


// 功能：UIWebView响应长按事件
-(BOOL)webView:(UIWebView *)webView shouldStartLoadWithRequest:(NSURLRequest *)_request navigationType:(UIWebViewNavigationType)navigationType
{
    return YES;  //非js调用时候，正常返回yes
}


-(void)openFn{
    NSLog(@"of");
    //oc调js的方法------- ocDiaoJS
    NSString *jsCode = [NSString stringWithFormat:@"javascript:%@()",@"ocDiaoJS"];
    [_webViewtemp stringByEvaluatingJavaScriptFromString:jsCode];
    //oc调js的方法-------
}

@end
