//$$$
//  DCIHTTPRequestMgr.m
//  PlatformApps
//
//  Created by kitegkp on 14-4-8.
//  Copyright (c) 2014年 chinadci. All rights reserved.
//

#import "DCIHTTPRequestMgr.h"

@implementation DCIHTTPRequestMgr


+ (DCIHTTPRequestMgr *)defaultInstance;
{
    static DCIHTTPRequestMgr *defaultInstance = nil;
    if(!defaultInstance)
        defaultInstance = [[super allocWithZone:nil] init];
    
    return defaultInstance;
}

+ (id)allocWithZone:(NSZone *)zone
{
    return [self defaultInstance];
}


//get 提交
-(void)requestTypeOfGetWithURL:(NSURL *)url withRequestInfo:(id)info withCallBackBlock:(CallBackMethod_Block)callBackBlock withErrorBlock:(ErrorMethod_Block)errorBlock{
    ASIHTTPRequest * request = [ASIHTTPRequest requestWithURL:url];/* 根据 URL, 获取 HTTP请求 */
    [request setRequestMethod:@"GET"];
    [request setDelegate:self];/* 注册异步回调方法对象 */
    [request startAsynchronous];/* 异步请求 */
    [request setResponseEncoding:NSUTF8StringEncoding];
    [request setUserInfo:[self setWithRequestInfo:info  withCallBackBlock:callBackBlock withErrorBlock:errorBlock]];
}


//post提交 form形式
-(void)requestTypeOfPostWithURL:(NSURL *)url withRequestInfo:(id)info withPostStr:(NSString*)jsonString withCallBackBlock:(CallBackMethod_Block)callBackBlock withErrorBlock:(ErrorMethod_Block)errorBlock{
    ASIHTTPRequest * request = [ASIHTTPRequest requestWithURL:url];/* 根据 URL, 获取 HTTP请求 */
    [request addRequestHeader:@"User-Agent" value:@"ASIHTTPRequest"];
    [request addRequestHeader:@"Content-Type" value:@"application/json; encoding=utf-8"];
    [request setRequestMethod:@"POST"];
    [request appendPostData:[jsonString dataUsingEncoding:NSUTF8StringEncoding]];
    [request setValidatesSecureCertificate:NO];//?
    [request setDelegate:self];/* 注册异步回调方法对象 */
    [request startAsynchronous];/* 异步请求 */
    [request setUserInfo:[self setWithRequestInfo:info  withCallBackBlock:callBackBlock withErrorBlock:errorBlock]];
}


//post提交, 以字节流进行提交数据
-(void)requestTypeOfPostByStreamWithURL:(NSURL *)url  withPostStr:(NSString*)jsonString withRequestInfo:(id)info withCallBackBlock:(CallBackMethod_Block)callBackBlock withErrorBlock:(ErrorMethod_Block)errorBlock{
    ASIHTTPRequest * request = [ASIHTTPRequest requestWithURL:url];/* 根据 URL, 获取 HTTP请求 */
    [request addRequestHeader:@"User-Agent" value:@"ASIHTTPRequest"];
    //[request addRequestHeader:@"Content-Type" value:@"application/x-www-form-urlencoded; encoding=utf-8"];
    [request addRequestHeader:@"Content-Type" value:@"application/octet-stream; encoding=utf-8"];
    [request setRequestMethod:@"POST"];
    [request appendPostData:[jsonString dataUsingEncoding:NSUTF8StringEncoding]];
    [request setValidatesSecureCertificate:NO];//?
    [request setDelegate:self];/* 注册异步回调方法对象 */
    [request startAsynchronous];/* 异步请求 */
    [request setUserInfo:[self setWithRequestInfo:info  withCallBackBlock:callBackBlock withErrorBlock:errorBlock]];
}

//设置操作成功和操作失败返回 tempObj保留 可能以后会记得发送者
-(NSMutableDictionary*)setWithRequestInfo:(id)info withCallBackBlock:(CallBackMethod_Block)callBackBlock withErrorBlock:(ErrorMethod_Block)errorBlock{
    NSMutableDictionary* tempDictionary=[[NSMutableDictionary alloc]init];
    [tempDictionary setValue:callBackBlock forKey:@"callBackBlock"];
    [tempDictionary setValue:errorBlock forKey:@"errorBlock"];
    [tempDictionary setValue:info forKey:@"info"];
    return tempDictionary;
}



// ASIHTTPRequest 异步请求回调函数
- (void)requestFinished:(ASIHTTPRequest *)request
{
    NSDictionary* tempDictionary=[request userInfo];
    ErrorMethod_Block _errorBack=[tempDictionary valueForKey:@"errorBlock"];
    CallBackMethod_Block _callBack=[tempDictionary valueForKey:@"callBackBlock"];
    id info=[tempDictionary valueForKey:@"info"];
    
    NSError * error = [request error];
    
    int responseStatusCode=[request responseStatusCode];
    if (responseStatusCode!=200) {   //通过状态判断返回错误
        NSString* responseHeaders = [request responseStatusMessage];
        NSString * response = (NSString *)[request responseString];
        NSLog(@"request访问url地址非200情况  %@",[request url]);
        NSLog(@"response: %@",response);

        if (_errorBack) {
            _errorBack(responseHeaders,info);
        }
    }
    else if(error)  //目前没发现error返回情况，暂时先存储
    {
        if (_errorBack) {
            _errorBack([error domain],info);
        }
    }
    else    //正常情况
    {
        //NSString * response = (NSString *)[[responseDelegate HTTPRequest] responseString];
        
        NSData * responseData = [request responseData];
        NSString * response = [[NSString alloc] initWithBytes:[responseData bytes] length:[responseData length] encoding:NSUTF8StringEncoding];
        //NSLog(@"%@", response);
        if (response != nil) {
            NSString *temp = response;
            if (temp != nil) {
                NSString *str = nil;
                NSInteger isStr=0;
                
                if (temp.length > 0 ) {
                    str = [temp substringWithRange:NSMakeRange(0, 1)];
                    if ([str localizedCaseInsensitiveCompare:@"\""] == NSOrderedSame) {
                        temp = [temp substringWithRange:NSMakeRange(1, temp.length - 1)];
                        isStr++;
                    }
                }
                
                if (temp.length > 0 ) {
                    str = [temp substringWithRange:NSMakeRange(temp.length - 1, 1)];
                    if ([str localizedCaseInsensitiveCompare:@"\""] == NSOrderedSame) {
                        temp = [temp substringWithRange:NSMakeRange(0, temp.length - 1)];
                        isStr++;
                    }
                }
                
                if (temp.length >= 2 && (isStr==2)) {
                    NSString *start = [temp substringWithRange:NSMakeRange(0, 1)];
                    NSString *end = [temp substringWithRange:NSMakeRange(temp.length - 1, 1)];
                    
                    // JSON 格式, 如果不匹配, 则是直接把结果当字符串处理
                    if (([start localizedCaseInsensitiveCompare:@"["] == NSOrderedSame && [end localizedCaseInsensitiveCompare:@"]"] == NSOrderedSame) || ([start localizedCaseInsensitiveCompare:@"{"] == NSOrderedSame && [end localizedCaseInsensitiveCompare:@"}"] == NSOrderedSame)) {
                        /* 服务返回的是字符串状态的 JSON数据, 服务以字符串形式返回, 而不是以映射类型式返回 */
                        /*   { "key":" value \\ value " }   */
                        /*   "{ "key":" value \\ value " }"   (错误形式,导致双引号和反斜杠会再进行转义, 字符串的开始和结束都会多出一个双引号, 从而导致在IOS端转成JOSN数据时无法转换, 只能作为字符串进行处理) */
                        /* JOSON数据格式必须是使用单引号, 不能使用单引号 */
                        /* 反斜杠也要转议 */
                        temp = [temp stringByReplacingOccurrencesOfString:@"\\" withString:@""];
                        response = temp;
                    }
                }
            }
            
            //NSLog(@"%@", response);
            //NSError *error = nil;
            id json = [NSJSONSerialization JSONObjectWithData:[response dataUsingEncoding:NSUTF8StringEncoding] options:NSJSONReadingAllowFragments error:&error];

            //兼容非json解析 服务经常返回true，BM00019453 等字符串或者BOOL型，直接把结果返回给相应类解析。
            if (json==nil && response.length!=0) { //json==nil 说明不能正确解析json，非json格式返回
                json =response;
            }
            
            if (_callBack) {
                _callBack(json,info);
            }
        }
    }
}


//异步取数失败执行
-(void)requestFailed:(ASIHTTPRequest *)request
{
    NSError *error = [request error];
    NSLog(@"request无法访问url地址  %@",[request url]);
    NSLog(@"%@",error);
    
    // NSLog(@"请求错误，请检查服务url地址或者网络连接情况!");
    NSDictionary* tempDictionary=[request userInfo];
    ErrorMethod_Block _errorBack=[tempDictionary valueForKey:@"errorBlock"];
        id info=[tempDictionary valueForKey:@"info"];
    if (_errorBack) {
             _errorBack(@"请求错误，请检查服务url地址或者网络连接情况!",info);
    }

}


@end
