//$$$
//  DCIHTTPRequestMgr.h
//  PlatformApps
//
//  Created by kitegkp on 14-4-8.
//  Copyright (c) 2014年 chinadci. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "ASIHTTPRequest.h"
//#import "JSONKit.h"


typedef void(^CallBackMethod_Block)(id ags ,id info);
typedef void(^ErrorMethod_Block)(id ags,id info);

@interface DCIHTTPRequestMgr : NSObject<ASIHTTPRequestDelegate>
{
  
}

+ (DCIHTTPRequestMgr *)defaultInstance;

//get 提交
-(void)requestTypeOfGetWithURL:(NSURL *)url withRequestInfo:(id)info withCallBackBlock:(CallBackMethod_Block)callBackBlock withErrorBlock:(ErrorMethod_Block)errorBlock;

//post提交 form形式
-(void)requestTypeOfPostWithURL:(NSURL *)url withRequestInfo:(id)info withPostStr:(NSString*)jsonString withCallBackBlock:(CallBackMethod_Block)callBackBlock withErrorBlock:(ErrorMethod_Block)errorBlock;

//post提交, 以字节流进行提交数据
-(void)requestTypeOfPostByStreamWithURL:(NSURL *)url  withPostStr:(NSString*)jsonString withRequestInfo:(id)info withCallBackBlock:(CallBackMethod_Block)callBackBlock withErrorBlock:(ErrorMethod_Block)errorBlock;




@end
