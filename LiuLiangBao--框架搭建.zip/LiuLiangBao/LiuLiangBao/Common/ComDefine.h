//
//  ComDefine.h
//  LiuLiangBao
//
//  Created by kitegkp on 15/7/15.
//  Copyright (c) 2015年 kitegkp. All rights reserved.
//

#ifndef LiuLiangBao_ComDefine_h
#define LiuLiangBao_ComDefine_h

#pragma mark - 值定义
/**
 @brief 定义遮罩的时间
 */

#define SVHUDDefaultTime 1.0f
#define SVHUDLongTime 3.0f




#pragma mark - 方法定义
/**
 @brief 获取系统版本号
 */
#define VERSION_FLOAT [[[UIDevice currentDevice] systemVersion] floatValue]


/**
 @brief 获取UIImage
 */
#define GetIMGWithName(name) [UIImage imageNamed:name]

/**
 @brief view宽
 */
#define VIEW_Width(view) (view.bounds.size.width)
/**
 @brief view frame height
 */
#define VIEW_Height(view) (view.bounds.size.height)







#endif
