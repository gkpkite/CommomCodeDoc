//
//  SettingClassObj.h
//  LiuLiangBao
//
//  Created by kitegkp on 15/7/25.
//  Copyright (c) 2015年 kitegkp. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface SettingClassInfo : NSObject

#pragma mark -获取设置界面信息
//设置对象的信息
+(NSDictionary*)getSettingViewInfo;

//设置的标题信息
+(NSDictionary*)getPreferenceSettingTitle;

//设置项的item信息
+(NSArray*)getPreferenceItems;



@end
