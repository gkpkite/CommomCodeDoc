//
//  SettingClassObj.m
//  LiuLiangBao
//  获取SettingFile.plist信息类
//  Created by kitegkp on 15/7/25.
//  Copyright (c) 2015年 kitegkp. All rights reserved.
//

#import "SettingClassInfo.h"

@implementation SettingClassInfo

// 获取应用的定制设置信息
+ (NSDictionary*)getSettingFileInfo {
    return [[NSDictionary alloc] initWithContentsOfFile:[[[NSBundle mainBundle] bundlePath]stringByAppendingPathComponent:[NSString stringWithFormat:@"SettingFile.plist"]]];
}

#pragma mark -获取设置界面信息
//设置对象的信息
+(NSDictionary*)getSettingViewInfo{
    NSDictionary *appSettings = [self getSettingFileInfo];
    NSDictionary* tempObj = [appSettings valueForKey:@"SettingViewInfo"];
    return tempObj;
}

//设置的标题信息
+(NSDictionary*)getPreferenceSettingTitle{
    NSDictionary *appSettings = [self getSettingViewInfo];
    NSDictionary* tempObj = [appSettings valueForKey:@"PreferenceSettingTitle"];
    return tempObj;
}

//设置项的item信息
+(NSArray*)getPreferenceItems{
    NSDictionary *appSettings = [self getSettingViewInfo];
    NSArray* tempObj = [appSettings valueForKey:@"PreferenceItems"];
    return tempObj;
}




@end
