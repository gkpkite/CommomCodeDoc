//
//  ColourHelp.h
//  LiuLiangBao
//
//  Created by kitegkp on 15/7/14.
//  Copyright (c) 2015年 kitegkp. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ColourHelp : NSObject
//颜色转成图片

+(UIImage *)createImageWithColor:(UIColor *)color;

//十六进制转颜色
+(UIColor *)getColorWithHex:(NSString*)hexColor;

@end
