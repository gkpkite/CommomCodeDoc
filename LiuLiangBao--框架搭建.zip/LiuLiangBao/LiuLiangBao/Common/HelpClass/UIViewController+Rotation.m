//
//  UIViewController+Rotation.m
//  LiuLiangBao
//  类别类
//  Created by kitegkp on 15/7/25.
//  Copyright (c) 2015年 kitegkp. All rights reserved.
//

#import "UIViewController+Rotation.h"


@implementation UIViewController (Rotation)

// IOS5默认支持竖屏
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

// IOS6默认不开启旋转，如果subclass需要支持屏幕旋转，重写这个方法return YES即可
- (BOOL)shouldAutorotate {
    return NO;
}

// IOS6默认支持竖屏
- (UIInterfaceOrientation)preferredInterfaceOrientationForPresentation {
    return UIInterfaceOrientationPortrait;
}

@end


// UINavigationController
@implementation UINavigationController (Rotation)

- (BOOL)shouldAutorotate {
    return [[self.viewControllers lastObject] shouldAutorotate];
}

- (NSUInteger)supportedInterfaceOrientations {
    return [[self.viewControllers lastObject] supportedInterfaceOrientations];
}

- (UIInterfaceOrientation)preferredInterfaceOrientationForPresentation {
    return [[self.viewControllers lastObject] preferredInterfaceOrientationForPresentation];
}

@end

// UITabBarController
@implementation UITabBarController (Rotation)

- (BOOL)shouldAutorotate {
    return [[self.viewControllers lastObject] shouldAutorotate];
}

- (NSUInteger)supportedInterfaceOrientations {
    return [[self.viewControllers lastObject] supportedInterfaceOrientations];
}

- (UIInterfaceOrientation)preferredInterfaceOrientationForPresentation {
    return [[self.viewControllers lastObject] preferredInterfaceOrientationForPresentation];
}

@end

// UIPageViewController
@implementation UIPageViewController (Rotation)

- (BOOL)shouldAutorotate {
    return (self.interfaceOrientation == UIInterfaceOrientationPortrait);
}

- (NSUInteger)supportedInterfaceOrientations {
    return NO;
}

- (UIInterfaceOrientation)preferredInterfaceOrientationForPresentation {
    return UIInterfaceOrientationPortrait;
}

@end

//--------------------GKP添加---------------

@implementation UIImage (iPhone5)

#define iPhone5 ([UIScreen instancesRespondToSelector:@selector(currentMode)] ? CGSizeEqualToSize(CGSizeMake(640, 1136), [[UIScreen mainScreen] currentMode].size) : NO)

+(UIImage *)imageNamedWithiPhone5:(NSString *)name imageTyped:(NSString *)type
{
    NSString *imgName = nil;
    if ([type length]==0) {
        type = @"png";
    }else
    {
        type = type;
    }
    if (iPhone5) {
        imgName = [NSString stringWithFormat:@"%@-568",name];
    }else{
        imgName = name;
    }
    
    // NSString *path = [[NSBundle mainBundle] pathForResource:imgName ofType:type];
    
    UIImage *image = [UIImage imageNamed:[NSString stringWithFormat:@"%@.%@",imgName,type]];//[UIImage imageWithContentsOfFile:path];
    
    return image;
}
@end


@implementation  NSObject(JsonCode)
//解析json存储的数据
+(id)jsonStrToOcObj:(id)info{
    if (info && [info isKindOfClass:[NSDictionary class]]) {
        NSDictionary* tempInfo=info;
        if (tempInfo && tempInfo.allKeys && tempInfo.allKeys.count<1) {  //没有数据
            return nil;
        }
        NSMutableDictionary * tempObj=[[NSMutableDictionary alloc]initWithCapacity:0];
        for (NSString * key in tempInfo.allKeys){
            [tempObj setValue:[self jsonStrToObj:[tempInfo valueForKey:key]] forKey:key];
        }
        return tempObj;
    }
    else if(info && [info isKindOfClass:[NSArray class]]){
        NSArray* tempInfo=info;
        if (tempInfo && tempInfo.count<1) {  //没有数据
            return nil;
        }
        NSMutableArray * tempObj=[[NSMutableArray alloc]initWithCapacity:0];
        for (NSDictionary * key in tempInfo){
            [tempObj addObject:[self jsonStrToOcObj:key]];
        }
        return tempObj;
    }
    else{
        return nil;
    }
}

+(id)jsonStrToObj:(NSString *)jsonstring{
    if (jsonstring == nil || [jsonstring isKindOfClass:[NSNull class]] || ([jsonstring isKindOfClass:[NSString class]] && [jsonstring isEqualToString:@""])) {  //没有数据时候
        return jsonstring;
    }
    
    NSError *error = nil;
    if ([jsonstring isKindOfClass:[NSString class]]) {
        id json = [NSJSONSerialization JSONObjectWithData:[jsonstring dataUsingEncoding:NSUTF8StringEncoding] options:NSJSONReadingMutableContainers error:&error];
        if (!error) {
            return json;
        }else{
            return jsonstring;
        }
    }else{
        return jsonstring;
    }
}
@end