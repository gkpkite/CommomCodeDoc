//
//  UIViewController+Rotation.h
//  LiuLiangBao
//
//  Created by kitegkp on 15/7/25.
//  Copyright (c) 2015年 kitegkp. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface UIViewController (Rotation)

@end

@interface UINavigationController (Rotation)

@end

@interface UITabBarController (Rotation)

@end

@interface UIPageViewController (Rotation)

@end

@interface UIImage (iPhone5)
//支持5的图片处理
+(UIImage *)imageNamedWithiPhone5:(NSString *)name imageTyped:(NSString *)type;
@end

@interface NSObject(JsonCode)
//解析json存储的数据
+(id)jsonStrToOcObj:(id)info;
+(id)jsonStrToObj:(NSString *)jsonstring;
@end
