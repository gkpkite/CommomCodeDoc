//
//  LLBUINavigationController.m
//  LiuLiangBao
//  头部View
//  Created by kitegkp on 15/7/14.
//  Copyright (c) 2015年 kitegkp. All rights reserved.
//

#import "LLBUINavigationController.h"
#import "ColourHelp.h"

@interface LLBUINavigationController ()

@end

@implementation LLBUINavigationController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
//    if (self.navigationBar) {  //背景色
//        self.navigationBar.barStyle = UIBarStyleBlack;
//        [self.navigationBar setBackgroundImage:[ColourHelp createImageWithColor:[UIColor colorWithRed:52/255.0 green:169/255.0 blue:223/255.0 alpha:1.0f]]  forBarMetrics:UIBarMetricsDefault ];
//    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.

}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/



@end
