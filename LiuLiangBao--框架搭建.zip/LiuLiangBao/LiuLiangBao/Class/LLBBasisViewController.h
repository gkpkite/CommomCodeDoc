//
//  LLBBasisViewController.h
//  LiuLiangBao
//  
//  Created by kitegkp on 15/7/25.
//  Copyright (c) 2015年 kitegkp. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LLBBasisViewController : UIViewController

@end
