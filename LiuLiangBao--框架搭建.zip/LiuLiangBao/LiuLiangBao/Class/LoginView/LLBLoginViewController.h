//
//  LLBLoginViewController.h
//  LiuLiangBao
//
//  Created by kitegkp on 15/7/25.
//  Copyright (c) 2015年 kitegkp. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "LLBBasisViewController.h"
/*
    登录成功返回
 */
typedef void(^LLBLoginView_Block)();

@interface LLBLoginViewController : LLBBasisViewController


//设置登录成功后返回的函数
-(void)setLoginView_Block:(LLBLoginView_Block)back;

@end
