//
//  LLBLoginViewController.m
//  LiuLiangBao
//  登录类
//  Created by kitegkp on 15/7/25.
//  Copyright (c) 2015年 kitegkp. All rights reserved.
//

#import "LLBLoginViewController.h"
#import "ComDefine.h"

@interface LLBLoginViewController()
{
    LLBLoginView_Block _loginView_Block;

}
@end


@implementation LLBLoginViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    UIButton *loginButton = [[UIButton alloc] initWithFrame:CGRectMake(0, 0, 205, 40)];
    loginButton.center = CGPointMake(VIEW_Width(self.view)*0.5f, VIEW_Height(self.view)*0.5f+150.f);
    [loginButton setTitle:@" 登录" forState:UIControlStateNormal];
    [loginButton sizeToFit];
    [loginButton addTarget:self action:@selector(finishGuideButtonClicked:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:loginButton];
    
    
}

//设置登录成功后返回的函数
-(void)setLoginView_Block:(LLBLoginView_Block)back{
    if(back){
        _loginView_Block=back;
    }
}

-(void)finishGuideButtonClicked:(id)sender
{
    if (_loginView_Block) {
        _loginView_Block();
    }
}


@end
