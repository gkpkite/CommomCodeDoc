//
//  SettingContentView.m
//  LiuLiangBao
//
//  Created by kitegkp on 15/8/8.
//  Copyright (c) 2015年 kitegkp. All rights reserved.
//

#import "SettingContentView.h"
#import "ColourHelp.h"


@interface SettingContentView()<UITableViewDataSource,UITableViewDelegate>
{
    UITableView* _tableView;
    UIView* _contentView;
    NSArray *_settingItems;
    NSString* _settingTitle;
    NSInteger _defaultHeight;
    NSInteger _defaultFontSize;
    NSInteger _defaultRightFontSize;
}
@end

@implementation SettingContentView

/*
 // Only override drawRect: if you perform custom drawing.
 // An empty implementation adversely affects performance during animation.
 - (void)drawRect:(CGRect)rect {
 // Drawing code
 }
 */

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
    }
    return self;
}

- (id)init
{
    self = [super init];
    if (self) {
        // Initialization code
    }
    return self;
}

-(void)initLayout{
    if (!_contentView) {
        _contentView=[[UIView alloc]init];
        [self addSubview:_contentView];
        [_contentView setBackgroundColor:[UIColor clearColor]];
    }
    _contentView.autoresizingMask=UIViewAutoresizingFlexibleWidth|UIViewAutoresizingFlexibleHeight|UIViewAutoresizingFlexibleTopMargin;
    _contentView.frame=CGRectMake(0,0,self.frame.size.width,self.frame.size.height);
    if (!_tableView) {
        _tableView=[[UITableView alloc]initWithFrame:CGRectMake(0,0,_contentView.frame.size.width,_contentView.frame.size.height) style:UITableViewStyleGrouped];
        [_contentView addSubview:_tableView];
        _tableView.dataSource=self;
        _tableView.delegate=self;
        [_tableView setBackgroundColor:[UIColor clearColor]];
    }
    _tableView.autoresizingMask=UIViewAutoresizingFlexibleWidth|UIViewAutoresizingFlexibleHeight|UIViewAutoresizingFlexibleTopMargin;
    _tableView.frame=CGRectMake(0,0,_contentView.frame.size.width,_contentView.frame.size.height);
    
    //头和尾
    if(self.settingDelegate && [self.settingDelegate respondsToSelector:NSSelectorFromString(@"getHeaderViewWithFram:")]){
        UIView * tempView=[self.settingDelegate getHeaderViewWithFram:CGRectMake(0, 0, _tableView.frame.size.width,0)];
        if (tempView) {
            [_tableView setTableHeaderView:tempView];
        }  
    }
    
    if(self.settingDelegate && [self.settingDelegate respondsToSelector:NSSelectorFromString(@"getFooterViewWithFram:")]){
        UIView * tempView=[self.settingDelegate getFooterViewWithFram:CGRectMake(0, 0, _tableView.frame.size.width,0)];
        if (tempView) {
            UIView* footView=[[UIView alloc] init];
            float height=tempView.frame.size.height;
            footView.frame=CGRectMake(0, 0, tempView.frame.size.width,height);
           
            tempView.frame=CGRectMake(0,footView.frame.size.height-height,footView.frame.size.width,height);
            tempView.autoresizingMask=UIViewAutoresizingFlexibleTopMargin|UIViewAutoresizingFlexibleWidth;
            [footView setBackgroundColor:[UIColor yellowColor]];
            
            [footView addSubview:tempView];
            [_tableView setTableFooterView:footView];
        }
    }
}

-(void)setTableHeaderView{

    UIView *view0 = [UIView new];
    view0.frame=CGRectMake(0, 0, _tableView.frame.size.width, 100);
    view0.backgroundColor = [UIColor yellowColor];
    [_tableView setTableHeaderView:view0];
    
    UIView *view = [UIView new];
    view.frame=CGRectMake(0, 0, _tableView.frame.size.width, 100);
    view.backgroundColor = [UIColor greenColor];
    [_tableView setTableFooterView:view];
}


#pragma mark- UITableViewDataSource


////每个section显示的标题
//- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section{
//    if (_settingItems!=nil && (section<_settingItems.count)) {
//        return  [[_settingItems objectAtIndex:section]objectForKey:@"PreferenceGroupName"];
//    }
//    else{
//        return nil;
//    }
//}

//多少个section
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    if (_settingItems!=nil) {
        return _settingItems.count;
    }
    else{
        return 0;
    }
}

//每个section 横数
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    
        NSLog(@"section00 %ld",(long)section);
    
    if (_settingItems!=nil && (section<_settingItems.count)) {
        NSArray* preferenceItem=[[_settingItems objectAtIndex:section]objectForKey:@"PreferenceItem"];
        return preferenceItem.count;
    }
    else{
        return 0;
    }
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *tableViewIdentifier = @"tableCell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:tableViewIdentifier];
    if (cell == nil) {
        cell = [[UITableViewCell alloc]     initWithStyle:UITableViewCellStyleValue1         reuseIdentifier:tableViewIdentifier];
    }
    //必须加上 因为表格复用时，cell  还是cell.contentView 都会累加控件的。
    if ([cell.contentView  subviews].count >0) {
        for (UIView * view in [cell.contentView  subviews]) {
            [view removeFromSuperview];
        }
    }
    //初始化cell
     UILabel * label = [cell textLabel];
    label.hidden=YES;
    cell.imageView.image=nil;
    cell.imageView.hidden=YES;
    
    
    
    NSInteger section=[indexPath section];
    
    if (section>_settingItems.count) {
        return cell;
    }
    NSUInteger row = [indexPath row];
    NSArray* preferenceItem=[[_settingItems objectAtIndex:section]objectForKey:@"PreferenceItem"];
    
    NSString * type=[[preferenceItem objectAtIndex:row]objectForKey:@"UIType"];
    
    if ([type isEqualToString:@"TextLabel"]) {
        cell.selectionStyle = UITableViewCellSelectionStyleNone;    //cell不能选中
        NSString *getLabelTextKey =[[preferenceItem objectAtIndex:row]valueForKey:@"GetLabelTextKey"];
        [self execGetLabelTextMessage:getLabelTextKey viewLabel:cell.textLabel];
        
    }else if([type isEqualToString:@"RightBtn"]) {
        cell.accessoryType=UITableViewCellAccessoryDisclosureIndicator;//详细按钮样式
        cell.selectionStyle = UITableViewCellSelectionStyleGray;    //cell选中
        
    }
    else if([type isEqualToString:@"ButtonType"]) {
        cell.selectionStyle = UITableViewCellSelectionStyleNone;    //cell不能选中
        [self addButtonChinld:cell WithObj:[preferenceItem objectAtIndex:row]]; //添加按钮
    }
    else if([type isEqualToString:@"Switch"]) {
        cell.selectionStyle = UITableViewCellSelectionStyleNone;    //cell不能选中
        [self addSwitchChinld:cell WithObj:[preferenceItem objectAtIndex:row]];
    }
    else if([type isEqualToString:@"SubfieldRightLabel"]) {         //左右分栏
        cell.selectionStyle = UITableViewCellSelectionStyleNone;    //cell不能选中
        
        NSString *getLabelTextKey =[[preferenceItem objectAtIndex:row]valueForKey:@"GetRightTextKey"];
       [self execGetRightLabelText:getLabelTextKey withDetailTextLabel:cell.detailTextLabel];
    }
    else if([type isEqualToString:@"SubfieldRightLabelAndBtn"]) {       //分栏
        cell.accessoryType=UITableViewCellAccessoryDisclosureIndicator;//详细按钮样式
        cell.selectionStyle = UITableViewCellSelectionStyleGray;    //cell选中
        
        NSString *getLabelTextKey =[[preferenceItem objectAtIndex:row]valueForKey:@"GetRightTextKey"];
        [self execGetRightLabelText:getLabelTextKey withDetailTextLabel:cell.detailTextLabel];
    }
    else if([type isEqualToString:@"View"]) {
        cell.selectionStyle = UITableViewCellSelectionStyleNone;    //cell不能选中
        NSString *key =[[preferenceItem objectAtIndex:row]valueForKey:@"GetViewKey"];
        [self execGetViewWithKey:key withCellContentView:cell.contentView withCell:cell];
        
    }
    else if([type isEqualToString:@"ViewAndRightBtn"]) {
        cell.accessoryType=UITableViewCellAccessoryDisclosureIndicator;//详细按钮样式
        cell.selectionStyle = UITableViewCellSelectionStyleGray;    //cell选中
        NSString *key =[[preferenceItem objectAtIndex:row]valueForKey:@"GetViewKey"];
        [self execGetViewWithKey:key withCellContentView:cell.contentView withCell:cell];
    }
    
    
    //label 显示数据
    if (!([type isEqualToString:@"ButtonType"] || [type isEqualToString:@"View"] || [type isEqualToString:@"ViewAndRightBtn"])) {
       label.hidden=NO;
#if __IPHONE_OS_VERSION_MAX_ALLOWED > __IPHONE_6_0
        label.lineBreakMode = NSLineBreakByWordWrapping;
#else
        label.lineBreakMode = UILineBreakModeWordWrap;
#endif
        [label setNumberOfLines:0];
        [label setFont:[UIFont systemFontOfSize:_defaultFontSize]];
        [label setTextColor:[UIColor colorWithRed:(80/255.00) green:(80/255.00) blue:(80/255.00) alpha:1]];
        cell.textLabel.text =[NSString stringWithFormat:@"%@",[[preferenceItem objectAtIndex:row]objectForKey:@"PreferenceItemTitle"]];
    }
    if([[preferenceItem objectAtIndex:row]valueForKey:@"IconImg"]){
        cell.imageView.hidden=NO;
        cell.imageView.image = [UIImage imageNamed:[[preferenceItem objectAtIndex:row]valueForKey:@"IconImg"]];
    }else{
        cell.imageView.hidden=YES;
        cell.imageView.image =nil;
    }
    
    return cell;
}

#pragma mark - UITableViewDelegate

-(void) tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath{
    if([indexPath row] == ((NSIndexPath*)[[tableView indexPathsForVisibleRows] lastObject]).row){
        NSInteger section=[indexPath section];
        NSUInteger row = [indexPath row];

        NSArray* preferenceItem=[[_settingItems objectAtIndex:section]objectForKey:@"PreferenceItem"];
        if (section==(_settingItems.count-1) && preferenceItem && (preferenceItem.count-1)==row) {  //显示最后一个时候
        NSLog(@"高度 %f %f %f",_tableView.frame.size.height,_tableView.contentSize.height,_tableView.tableFooterView.frame.size.height);
        //调整底部靠近下方
        if (tableView.bounds.size.height>(tableView.contentSize.height)) {
                _tableView.tableFooterView.frame=CGRectMake(_tableView.tableFooterView.frame.origin.x,_tableView.tableFooterView.frame.origin.y, _tableView.tableFooterView.frame.size.width,tableView.frame.size.height-(tableView.contentSize.height-_tableView.tableFooterView.frame.size.height));
        }
                  }
}
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    NSInteger section=[indexPath section];
    NSUInteger row = [indexPath row];
    NSArray* preferenceItem=[[_settingItems objectAtIndex:section]objectForKey:@"PreferenceItem"];
    //[preferenceItem objectAtIndex:row]
    NSString * cellHeightStr=[[preferenceItem objectAtIndex:row] valueForKey:@"CellHeight"];
    if (cellHeightStr) {
        return [cellHeightStr floatValue];
    }
    return _defaultHeight;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSInteger section=[indexPath section];
    if (section>_settingItems.count) {
        return ;
    }
    NSUInteger row = [indexPath row];
    NSArray* preferenceItem=[[_settingItems objectAtIndex:section]objectForKey:@"PreferenceItem"];
    NSString * type=[[preferenceItem objectAtIndex:row]objectForKey:@"UIType"];
    
    if([type isEqualToString:@"RightBtn"] || [type isEqualToString:@"SubfieldRightLabelAndBtn"] || [type isEqualToString:@"ViewAndRightBtn"]) {
        [self executeSelExecutionMeth:indexPath];
    }
    
    
}
//tableView右边按钮点击
- (void)tableView:(UITableView *)tableView accessoryButtonTappedForRowWithIndexPath:(NSIndexPath *)indexPath{
    NSInteger section=[indexPath section];
    if (section>_settingItems.count) {
        return ;
    }
    [self executeSelExecutionMeth:indexPath];
}


#pragma mark - 添加类型
//按钮框
-(void)addButtonChinld:(UITableViewCell*)cell WithObj:(NSDictionary*)obj{
    UIButton*   tempBtn=[UIButton  buttonWithType:UIButtonTypeCustom];
    [cell.contentView addSubview:tempBtn];
    
    if ([obj valueForKey:@"BtnBackColour"]) {
        [tempBtn setBackgroundColor:[ColourHelp getColorWithHex:[obj valueForKey:@"BtnBackColour"]]];
    }else{
        [tempBtn setBackgroundColor:[UIColor redColor]];
    }
    
    if ([obj valueForKey:@"BtnTextColour"]) {
        [tempBtn setTitleColor:[ColourHelp getColorWithHex:[obj valueForKey:@"BtnTextColour"]] forState:UIControlStateNormal];
    }else{
        [tempBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    }
    
    [tempBtn.titleLabel setFont:[UIFont systemFontOfSize:18.0]];
    [tempBtn setTitle:[obj objectForKey:@"PreferenceItemTitle"]  forState:UIControlStateNormal];
    tempBtn.autoresizingMask = UIViewAutoresizingFlexibleWidth + UIViewAutoresizingFlexibleHeight; //宽度 高度都变化
    tempBtn.frame=CGRectMake(0,0,cell.contentView.frame.size.width,cell.contentView.frame.size.height);
    NSString* selExecutionMethod =[obj objectForKey:@"SelExecutionMethod"];
    
    if (self.settingDelegate  && [self.settingDelegate respondsToSelector:NSSelectorFromString(selExecutionMethod)]) {
        [tempBtn addTarget:self.settingDelegate action:NSSelectorFromString(selExecutionMethod) forControlEvents:UIControlEventTouchDown]; //注册点击事件
    }
}


//选择框
-(void)addSwitchChinld:(UITableViewCell*)cell WithObj:(NSDictionary*)obj{
    //添加切换项
    UISwitch *switchButton=[[UISwitch alloc]init];
    [switchButton setBackgroundColor:[UIColor clearColor]];
    
    if ([obj valueForKey:@"SwitchBackColour"]) {
        switchButton.onTintColor=[ColourHelp getColorWithHex:[obj valueForKey:@"SwitchBackColour"]];
    }else{
        switchButton.onTintColor=[UIColor redColor];
    }
    
    [cell.contentView addSubview:switchButton];
    NSString *selExecutionMethod =[obj  objectForKey:@"SelExecutionMethod"];
    if(self.settingDelegate && [self.settingDelegate respondsToSelector:NSSelectorFromString(selExecutionMethod)]){
        [switchButton addTarget:self.settingDelegate action:NSSelectorFromString(selExecutionMethod) forControlEvents:UIControlEventValueChanged]; //注册点击事件
    }
    switchButton.autoresizingMask =UIViewAutoresizingFlexibleLeftMargin;
    switchButton.frame=CGRectMake(cell.contentView.bounds.size.width-switchButton.frame.size.width-8,(cell.contentView.bounds.size.height-switchButton.frame.size.height)/2.00,switchButton.frame.size.width,switchButton.frame.size.height);
    NSString* switchingKey =[obj objectForKey:@"SwitchingKey"];
    
    //设置初始值
    if(self.settingDelegate && [self.settingDelegate respondsToSelector:NSSelectorFromString(@"getValueWithSwitchingKey:")]){
        [switchButton setOn:[self.settingDelegate getValueWithSwitchingKey:switchingKey]];
    }
}

//执行取值信息
-(void)execGetLabelTextMessage:(NSString*)getLabelTextKey  viewLabel:(id)label{
    if(self.settingDelegate && [self.settingDelegate respondsToSelector:NSSelectorFromString(@"getValueWithTextKey:")]){
        ((UILabel*)label).text =[self.settingDelegate  getValueWithTextKey:getLabelTextKey];
    }
}

//执行右边label取值信息
-(void)execGetRightLabelText:(NSString*)getRightTextKey  withDetailTextLabel:(UILabel*)detailTextLabel
{
    if(self.settingDelegate && [self.settingDelegate respondsToSelector:NSSelectorFromString(@"getRightLabelValueWithTextKey:")]){
        detailTextLabel.autoresizingMask=UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
        detailTextLabel.text =[self.settingDelegate  getRightLabelValueWithTextKey:getRightTextKey];
        detailTextLabel.textAlignment=NSTextAlignmentRight;
        [detailTextLabel setFont:[UIFont systemFontOfSize:_defaultRightFontSize]];
        [detailTextLabel setTextColor:[UIColor colorWithRed:(210/255.00) green:(210/255.00) blue:(210/255.00) alpha:1]];;
    }
}


//执行view信息
-(void)execGetViewWithKey:(NSString*)key  withCellContentView:(UIView*)view  withCell:(UIView*)cellView {
    if(self.settingDelegate && [self.settingDelegate respondsToSelector:NSSelectorFromString(@"getViewWithKey:withPreView:withCell:")]){
        [self.settingDelegate getViewWithKey:key  withPreView:view withCell:cellView];
    }
    
}

//执行RightBtn选中方法
-(void)executeSelExecutionMeth:(NSIndexPath *)indexPath{
    NSInteger section=[indexPath section];
    NSUInteger row = [indexPath row];
    NSArray* preferenceItem=[[_settingItems objectAtIndex:section]objectForKey:@"PreferenceItem"];
    NSString *selExecutionMethod =[[preferenceItem objectAtIndex:row]objectForKey:@"SelExecutionMethod"];
    if (selExecutionMethod==nil) {
        return;
    }
    if(self.settingDelegate && [self.settingDelegate respondsToSelector:NSSelectorFromString(selExecutionMethod)]){
        SEL selector =NSSelectorFromString(selExecutionMethod);
        NSMethodSignature *methodSig = [[self.settingDelegate class] instanceMethodSignatureForSelector:selector];
        NSInvocation *invocation = [NSInvocation invocationWithMethodSignature:methodSig];
        [invocation setSelector:selector];
        NSString* aa=[[preferenceItem objectAtIndex:row]objectForKey:@"PreferenceItemTitle"];
        [invocation setArgument:&aa  atIndex:2];  //：0 1 两个参数已经被target 和selector占用
        [invocation setTarget:self.settingDelegate];
        [invocation invoke];
    }
}



#pragma mark 数据

//刷新界面
-(void)reloadData{
    [_tableView reloadData];  //刷新数据
}



//刷新数据
-(void)loadViewData:(NSDictionary*)viewData{
    [self initLayout];
    [self setBackgroundColor:[UIColor colorWithRed:240/255.0 green:240/255.0 blue:240/255.0 alpha:1]];
    _settingTitle=[[NSString alloc]initWithString:[viewData objectForKey:@"PreferenceSettingTitle"]];
    _settingItems=[[NSArray alloc]initWithArray:[viewData objectForKey:@"PreferenceItems"]];
    
    NSString * imgOrxStr=[viewData valueForKey:@"ImgOrx"];
    NSInteger imgOrx=0;
    if (imgOrxStr) {
        imgOrx=[imgOrxStr integerValue];
    }
    
    _defaultHeight=44;
    NSString * defaultHeightStr=[viewData valueForKey:@"DefaultHeight"];
    if (defaultHeightStr) {
        _defaultHeight=[defaultHeightStr integerValue];
    }
    
    _defaultFontSize=18;
    NSString * defaultFontSizeStr=[viewData valueForKey:@"DefaultFontSize"];
    if (defaultFontSizeStr) {
        _defaultFontSize=[defaultFontSizeStr integerValue];
    }
    
    _defaultRightFontSize=11;
    NSString * defaultRightFontSizeStr=[viewData valueForKey:@"DefaultRightFontSize"];
    if (defaultRightFontSizeStr) {
        _defaultRightFontSize=[defaultRightFontSizeStr integerValue];
    }
    
    
    if ([_tableView respondsToSelector:@selector(setSeparatorInset:)])
    {
        _tableView.separatorInset = UIEdgeInsetsMake(0,imgOrx, 0, 0);
    }
    
    [self reloadData];  //刷新数据
}

////布局时候调整
//- (void)layoutSubviews{
//    [super layoutSubviews];
//    NSLog(@"self.view.frame.size.height2 %f",self.frame.size.height);
//}


@end
