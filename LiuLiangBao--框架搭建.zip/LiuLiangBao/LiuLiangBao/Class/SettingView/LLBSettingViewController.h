//
//  LLBSettingViewController.h
//  LiuLiangBao
//
//  Created by kitegkp on 15/7/15.
//  Copyright (c) 2015年 kitegkp. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "LLBBasisViewController.h"

@interface LLBSettingViewController : LLBBasisViewController

@end
