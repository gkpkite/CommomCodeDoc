//
//  LLBSettingViewController.m
//  LiuLiangBao
//  设置界面
//  Created by kitegkp on 15/7/15.
//  Copyright (c) 2015年 kitegkp. All rights reserved.
//

#import "LLBSettingViewController.h"
#import "SettingContentView.h"

@interface LLBSettingViewController ()<SettingDelegate>
{
//    UITableView *_dataTableView;
    SettingContentView * _settingContentView;
}
@end

@implementation LLBSettingViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    [self initLayout];

}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

// 初始化布局
-(void)initLayout{
   // NSLog(@"self.view.frame.size.height %f",self.view.frame.size.height);
    if (!_settingContentView) {
        _settingContentView=[[SettingContentView alloc] initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height)];
        [self.view addSubview:_settingContentView];
        [_settingContentView setBackgroundColor:[UIColor blueColor]];
        [self.view setBackgroundColor:[UIColor yellowColor]];
        _settingContentView.settingDelegate=self;
        _settingContentView.autoresizingMask=UIViewAutoresizingFlexibleWidth|UIViewAutoresizingFlexibleHeight;
    }
    
    [_settingContentView loadViewData:[SettingClassInfo getSettingViewInfo]];
}


#pragma mark - SettingDelegate
//switch初始值
-(BOOL)getValueWithSwitchingKey:(NSString*)switchingKey{

    if ([switchingKey isEqualToString:@"SwitchingTest"]) {
        return YES;
    }
    return NO;
}

//获取文本的值
-(NSString *)getValueWithTextKey:(NSString*)textKey
{
    if ([textKey isEqualToString:@"TextLabelKey"]) {
        return @"TextLabelKey类型--";
    }
    
return @"";
}


//获取右边文本的值
-(NSString *)getRightLabelValueWithTextKey:(NSString*)textKey
{
    if ([textKey isEqualToString:@"SubfieldLabelKey"]) {
        return @"分栏类型";
    }
    if ([textKey isEqualToString:@"SubfieldRightLabelAndBtnLabelKey"]) {
        return @"分栏右边按钮类型";
    }
    return @"";

}

//获取view
-(void)getViewWithKey:(NSString*)key  withPreView:(UIView*)view withCell:(UIView*)cellView{

    if ([key isEqualToString:@"ViewTest"]) {
        
            [self addAboutViewWithPreView:view withCell:cellView];

    }
    if ([key isEqualToString:@"ViewRightBtnTest"]) {
            [self addAboutViewWithPreView:view withCell:cellView];
    }
}

//key
-(UIView*)getHeaderViewWithFram:(CGRect)frame
{

     UIView * view=[[UIView alloc] init];
    frame.size.height=300;
     view.frame=frame;

    [view setBackgroundColor:[UIColor redColor]];
    return view;
}

//key
-(UIView*)getFooterViewWithFram:(CGRect)frame
{
    UIView * view=[[UIView alloc] init];
    frame.size.height=100;
    view.frame=frame;

    [view setBackgroundColor:[UIColor greenColor]];
    return view;
}


-(void)addAboutViewWithPreView:(UIView*)preView withCell:(UIView*)cellView{
    UIView * view=[[UIView alloc] init];
    view.frame=CGRectMake(0, 0, preView.frame.size.width, preView.frame.size.height);
    view.autoresizingMask=UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    [preView addSubview:view];
    
    UIImageView*  iconImg=[[UIImageView alloc]init];
    iconImg.frame=CGRectMake((view.frame.size.width-114)/2,30, 114, 114);
    [view addSubview:iconImg];
    iconImg.autoresizingMask=UIViewAutoresizingFlexibleLeftMargin|UIViewAutoresizingFlexibleRightMargin;
    iconImg.image=[UIImage imageNamed:@"tool57.png"];
    
    UILabel*  vLabel=[[UILabel alloc] init];
    [view addSubview:vLabel];
    vLabel.frame=CGRectMake(0,30+114+15,view.bounds.size.width,15);
    vLabel.autoresizingMask=UIViewAutoresizingFlexibleWidth;
    [vLabel setTextAlignment:NSTextAlignmentCenter];
    [vLabel setTextColor:[UIColor lightGrayColor]];
    
    [vLabel setText:@"V1.0"];
    [preView  setBackgroundColor:[UIColor clearColor]];
    [view  setBackgroundColor:[UIColor clearColor]];
    [cellView setBackgroundColor:[UIColor clearColor]];
}


#pragma mark -配置右边的按钮触发事件

-(void)RightBtnAction:(id)sender
{
    NSLog(@"选中按钮");
}

-(void)ButtonTypeAction:(id)sender
{

    NSLog(@"按钮事件");
}

-(void)SwitchAction:(id)sender
{
    NSLog(@"切换按钮事件");

}




@end
