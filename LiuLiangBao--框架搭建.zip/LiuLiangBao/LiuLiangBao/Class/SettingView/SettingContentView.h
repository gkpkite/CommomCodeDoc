//
//  SettingContentView.h
//  LiuLiangBao
//
//  Created by kitegkp on 15/8/8.
//  Copyright (c) 2015年 kitegkp. All rights reserved.
//

#import <UIKit/UIKit.h>


#import <UIKit/UIKit.h>


@protocol SettingDelegate <NSObject>
@optional
//switch初始值
-(BOOL)getValueWithSwitchingKey:(NSString*)switchingKey;
//获取文本的值
-(NSString *)getValueWithTextKey:(NSString*)textKey;
//获取右边文本的值
-(NSString *)getRightLabelValueWithTextKey:(NSString*)textKey;

//key
//获取view
-(void)getViewWithKey:(NSString*)key  withPreView:(UIView*)view withCell:(UIView*)cellView;

-(UIView*)getHeaderViewWithFram:(CGRect)frame;

-(UIView*)getFooterViewWithFram:(CGRect)frame;

@end

@interface SettingContentView : UIView

@property(nonatomic,assign) id<SettingDelegate>settingDelegate;

//刷新数据
-(void)loadViewData:(NSDictionary*)viewData;

@end
