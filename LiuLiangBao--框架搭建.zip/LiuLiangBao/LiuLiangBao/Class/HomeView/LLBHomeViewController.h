//
//  LLBHomeViewController.h
//  LiuLiangBao
//
//  Created by kitegkp on 15/7/25.
//  Copyright (c) 2015年 kitegkp. All rights reserved.
//

#import "LLBBasisViewController.h"

@interface LLBHomeViewController : LLBBasisViewController

@end
