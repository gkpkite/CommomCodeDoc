//
//  LLBTabBarViewController.m
//  LiuLiangBao
//  底部选项View
//  Created by kitegkp on 15/7/14.
//  Copyright (c) 2015年 kitegkp. All rights reserved.
//


#import "LLBTabBarViewController.h"
#import "LLBUINavigationController.h"
//#import "ComDefine.h"
#import "LLBUINavigationController.h"
#import "ColourHelp.h"

#import "LLBHomeViewController.h"
#import "LLBSettingViewController.h"


@interface LLBTabBarViewController ()

@end

@implementation LLBTabBarViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    [self initLayout];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

#pragma mark- 初始化布局
-(void)initLayout{

    LLBHomeViewController *viewController0 = [[LLBHomeViewController alloc] init];
    //选中可以变颜色 加上这里设置颜色
    viewController0.tabBarItem.image = (VERSION_FLOAT >= 7.0f) ? [UIImage imageNamed:@"zhuye.png"]:[UIImage imageNamed:@"zhuye.png"];
    viewController0.tabBarItem.title=@"主页0";
    
    
    LLBHomeViewController *viewController1 = [[LLBHomeViewController alloc] init];
    viewController1.tabBarItem.image = (VERSION_FLOAT >= 7.0f) ? [UIImage imageNamed:@"zhuye.png"]:[UIImage imageNamed:@"zhuye.png"];
    viewController1.tabBarItem.title=@"主页1";
    
    
    LLBHomeViewController *viewController2 = [[LLBHomeViewController alloc] init];
    viewController2.tabBarItem.image = (VERSION_FLOAT >= 7.0f) ? [UIImage imageNamed:@"zhuye.png"]:[UIImage imageNamed:@"zhuye.png"];
    viewController2.tabBarItem.title=@"主页2";
    
    
    LLBHomeViewController *viewController3= [[LLBHomeViewController alloc] init];
    viewController3.tabBarItem.image = (VERSION_FLOAT >= 7.0f) ? [UIImage imageNamed:@"zhuye.png"]:[UIImage imageNamed:@"zhuye.png"];
    viewController3.tabBarItem.title=@"主页3";
    
    
    LLBSettingViewController *viewController4= [[LLBSettingViewController alloc] init];
    viewController4.tabBarItem.image = (VERSION_FLOAT >= 7.0f) ? [UIImage imageNamed:@"zhuye.png"]:[UIImage imageNamed:@"zhuye.png"];
    viewController4.tabBarItem.title=@"设置";
    

    LLBUINavigationController *nav0 = [[LLBUINavigationController alloc] initWithRootViewController:viewController0];
    LLBUINavigationController *nav1 = [[LLBUINavigationController alloc] initWithRootViewController:viewController1];
    LLBUINavigationController *nav2 = [[LLBUINavigationController alloc] initWithRootViewController:viewController2];
    LLBUINavigationController *nav3 = [[LLBUINavigationController alloc] initWithRootViewController:viewController3];
    LLBUINavigationController *nav4 = [[LLBUINavigationController alloc] initWithRootViewController:viewController4];
    
    [nav0.navigationBar.topItem setTitle:@"主页0"];
    [nav1.navigationBar.topItem setTitle:@"主页1"];
    [nav2.navigationBar.topItem setTitle:@"主页2"];
    [nav3.navigationBar.topItem setTitle:@"主页3"];
    [nav4.navigationBar.topItem setTitle:@"设置"];
    
    self.viewControllers = @[nav0,nav1,nav2,nav3,nav4];
    self.tabBar.tintColor = [UIColor colorWithRed:52/255.0 green:169/255.0 blue:223/255.0 alpha:1.0f];
}


@end
